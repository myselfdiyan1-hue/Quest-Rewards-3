package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.ui.theme.CoinGold
import com.example.ui.theme.GemCyan
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.YellowAccent

@Composable
fun AppLogoBadge(modifier: Modifier = Modifier, size: Dp = 96.dp) {
    val cornerRadius = size * 0.26f
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF1E3A8A),
                        Color(0xFF1D4ED8),
                        Color(0xFF0F172A)
                    )
                )
            )
            .border(
                width = (size.value * 0.028f).dp.coerceAtLeast(2.dp),
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF38BDF8),
                        Color(0xFFFBBF24),
                        Color(0xFF38BDF8)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "Quest Rewards App Logo",
            modifier = Modifier.size(size * 1.15f)
        )
    }
}

@Composable
fun GoldCoinIcon(modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Canvas(modifier = modifier.size(size)) {
        val s = this.size.minDimension
        val center = Offset(s / 2, s / 2)
        // Outer glow/rim
        drawCircle(
            color = Color(0xFFD6940C),
            radius = s * 0.48f,
            center = center
        )
        // Main gold body
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(YellowAccent, CoinGold, Color(0xFFE29E0B)),
                center = Offset(s * 0.35f, s * 0.35f),
                radius = s * 0.6f
            ),
            radius = s * 0.44f,
            center = center
        )
        // Inner ridge
        drawCircle(
            color = Color(0xFFFFE66D),
            radius = s * 0.34f,
            center = center,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = s * 0.06f)
        )
        // Star or emblem in center
        val path = Path().apply {
            val rIn = s * 0.12f
            val rOut = s * 0.22f
            for (i in 0 until 4) {
                val angleOut = Math.toRadians((i * 90.0) - 90.0)
                val angleIn = Math.toRadians((i * 90.0 + 45.0) - 90.0)
                val xOut = center.x + (rOut * Math.cos(angleOut)).toFloat()
                val yOut = center.y + (rOut * Math.sin(angleOut)).toFloat()
                val xIn = center.x + (rIn * Math.cos(angleIn)).toFloat()
                val yIn = center.y + (rIn * Math.sin(angleIn)).toFloat()
                if (i == 0) moveTo(xOut, yOut) else lineTo(xOut, yOut)
                lineTo(xIn, yIn)
            }
            close()
        }
        drawPath(path, color = Color.White)
    }
}

@Composable
fun CyanGemIcon(modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Top triangle facet
        val topPath = Path().apply {
            moveTo(w * 0.22f, h * 0.30f)
            lineTo(w * 0.78f, h * 0.30f)
            lineTo(w * 0.50f, h * 0.50f)
            close()
        }
        drawPath(
            topPath,
            brush = Brush.verticalGradient(listOf(Color(0xFF8CEEFF), GemCyan))
        )

        // Left facet
        val leftPath = Path().apply {
            moveTo(w * 0.22f, h * 0.30f)
            lineTo(w * 0.50f, h * 0.50f)
            lineTo(w * 0.50f, h * 0.88f)
            lineTo(w * 0.12f, h * 0.44f)
            close()
        }
        drawPath(leftPath, color = Color(0xFF0EA5D8))

        // Right facet
        val rightPath = Path().apply {
            moveTo(w * 0.78f, h * 0.30f)
            lineTo(w * 0.88f, h * 0.44f)
            lineTo(w * 0.50f, h * 0.88f)
            lineTo(w * 0.50f, h * 0.50f)
            close()
        }
        drawPath(rightPath, color = Color(0xFF0284C7))

        // Center shine diamond
        val shinePath = Path().apply {
            moveTo(w * 0.35f, h * 0.34f)
            lineTo(w * 0.55f, h * 0.34f)
            lineTo(w * 0.50f, h * 0.46f)
            close()
        }
        drawPath(shinePath, color = Color.White.copy(alpha = 0.8f))
    }
}

@Composable
fun TreasureChestIllustration(modifier: Modifier = Modifier, size: Dp = 72.dp) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(YellowAccent.copy(alpha = 0.4f), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.4f),
                radius = w * 0.5f
            )
        )

        // Chest Body (Lower)
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFB45309), Color(0xFF78350F))),
            topLeft = Offset(w * 0.15f, h * 0.45f),
            size = Size(w * 0.70f, h * 0.42f),
            cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
        )

        // Chest Lid (Curved Top)
        val lidPath = Path().apply {
            moveTo(w * 0.12f, h * 0.45f)
            cubicTo(w * 0.12f, h * 0.20f, w * 0.88f, h * 0.20f, w * 0.88f, h * 0.45f)
            close()
        }
        drawPath(
            lidPath,
            brush = Brush.verticalGradient(listOf(Color(0xFFD97706), Color(0xFF92400E)))
        )

        // Gold Trim Bands
        drawRoundRect(
            color = CoinGold,
            topLeft = Offset(w * 0.28f, h * 0.24f),
            size = Size(w * 0.08f, h * 0.63f),
            cornerRadius = CornerRadius(w * 0.02f, w * 0.02f)
        )
        drawRoundRect(
            color = CoinGold,
            topLeft = Offset(w * 0.64f, h * 0.24f),
            size = Size(w * 0.08f, h * 0.63f),
            cornerRadius = CornerRadius(w * 0.02f, w * 0.02f)
        )

        // Center Gold Lock Clasp
        drawRoundRect(
            brush = Brush.linearGradient(listOf(YellowAccent, OrangeAccent)),
            topLeft = Offset(w * 0.43f, h * 0.40f),
            size = Size(w * 0.14f, h * 0.16f),
            cornerRadius = CornerRadius(w * 0.03f, w * 0.03f)
        )
        // Keyhole
        drawCircle(
            color = Color(0xFF451A03),
            radius = w * 0.025f,
            center = Offset(w * 0.50f, h * 0.46f)
        )

        // Emerging Gems / Coins Sparkles
        drawCircle(
            color = GemCyan,
            radius = w * 0.05f,
            center = Offset(w * 0.22f, h * 0.20f)
        )
        drawCircle(
            color = YellowAccent,
            radius = w * 0.04f,
            center = Offset(w * 0.78f, h * 0.22f)
        )
    }
}

@Composable
fun TrophyAvatar(modifier: Modifier = Modifier, size: Dp = 44.dp) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    colors = listOf(PrimaryBlue, PurpleAccent)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.65f)) {
            val w = this.size.width
            val h = this.size.height

            // Trophy Cup
            val cupPath = Path().apply {
                moveTo(w * 0.25f, h * 0.15f)
                lineTo(w * 0.75f, h * 0.15f)
                cubicTo(w * 0.75f, h * 0.55f, w * 0.25f, h * 0.55f, w * 0.25f, h * 0.15f)
                close()
            }
            drawPath(cupPath, color = CoinGold)

            // Cup Stem
            drawRect(
                color = CoinGold,
                topLeft = Offset(w * 0.44f, h * 0.50f),
                size = Size(w * 0.12f, h * 0.22f)
            )

            // Base
            drawRoundRect(
                color = CoinGold,
                topLeft = Offset(w * 0.28f, h * 0.72f),
                size = Size(w * 0.44f, h * 0.14f),
                cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
            )

            // Star
            drawCircle(
                color = Color.White,
                radius = w * 0.06f,
                center = Offset(w * 0.5f, h * 0.32f)
            )
        }
    }
}

/**
 * Visual graphic for each Image Finder item
 */
@Composable
fun GameObjectGraphic(name: String, modifier: Modifier = Modifier, size: Dp = 48.dp) {
    val emoji = when (name.lowercase()) {
        "apple" -> "🍎"
        "car" -> "🚗"
        "banana" -> "🍌"
        "dog" -> "🐶"
        "football" -> "⚽"
        "cat" -> "🐱"
        "parrot" -> "🦜"
        "bicycle" -> "🚲"
        "tree" -> "🌳"
        else -> "⭐"
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = emoji,
            fontSize = (size.value * 0.58f).sp
        )
    }
}
