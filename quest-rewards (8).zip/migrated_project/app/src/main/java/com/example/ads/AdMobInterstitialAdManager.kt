package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.example.data.model.TestConfig
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class AdMobInterstitialAdManager(private val context: Context) {

    private val TAG = "AdMobInterstitialAdMgr"
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false
    private var isShowing = false
    private var lastShownTimeMs = 0L

    companion object {
        // Frequency cap: at least 90 seconds between interstitial ads so UX stays smooth
        private const val MIN_INTERSTITIAL_INTERVAL_MS = 90_000L
    }

    init {
        loadInterstitialAd()
    }

    fun loadInterstitialAd() {
        if (isLoading || interstitialAd != null) return
        isLoading = true

        try {
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                context,
                TestConfig.ADMOB_INTERSTITIAL_AD_UNIT_ID,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        Log.d(TAG, "Interstitial Ad loaded successfully.")
                        isLoading = false
                        interstitialAd = ad
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.w(TAG, "Interstitial Ad failed to load (${loadAdError.code}): ${loadAdError.message}")
                        isLoading = false
                        interstitialAd = null
                    }
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Exception loading Interstitial Ad", e)
            isLoading = false
            interstitialAd = null
        }
    }

    /**
     * Shows an interstitial ad only when loaded and outside cooldown.
     * Never blocks user flow or crashes on failure.
     */
    fun showIfReady(activity: Activity?, onFinished: (() -> Unit)? = null) {
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            onFinished?.invoke()
            return
        }

        val now = System.currentTimeMillis()
        if (isShowing || (now - lastShownTimeMs) < MIN_INTERSTITIAL_INTERVAL_MS) {
            onFinished?.invoke()
            return
        }

        val ad = interstitialAd
        if (ad == null) {
            loadInterstitialAd()
            onFinished?.invoke()
            return
        }

        interstitialAd = null
        isShowing = true

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                lastShownTimeMs = System.currentTimeMillis()
                Log.d(TAG, "Interstitial Ad shown.")
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "Interstitial Ad failed to show: ${adError.message}")
                isShowing = false
                loadInterstitialAd()
                onFinished?.invoke()
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "Interstitial Ad dismissed.")
                isShowing = false
                loadInterstitialAd()
                onFinished?.invoke()
            }
        }

        try {
            ad.show(activity)
        } catch (e: Exception) {
            Log.e(TAG, "Exception showing Interstitial Ad", e)
            isShowing = false
            loadInterstitialAd()
            onFinished?.invoke()
        }
    }
}
