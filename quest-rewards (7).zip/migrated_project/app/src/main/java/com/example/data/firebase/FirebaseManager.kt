package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

class FirebaseManager(private val context: Context) {
    private val TAG = "FirebaseManager"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val auth: FirebaseAuth by lazy {
        ensureFirebaseInitialized(context)
        FirebaseAuth.getInstance()
    }
    val firestore: FirebaseFirestore by lazy {
        ensureFirebaseInitialized(context)
        FirebaseFirestore.getInstance()
    }

    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val _userProfile = MutableStateFlow<UserProfile?>(null)
    val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _isCheckingSession = MutableStateFlow(false)
    val isCheckingSession: StateFlow<Boolean> = _isCheckingSession.asStateFlow()

    private val _isUserBlocked = MutableStateFlow(false)
    val isUserBlocked: StateFlow<Boolean> = _isUserBlocked.asStateFlow()

    private val _appConfig = MutableStateFlow(AppConfig())
    val appConfig: StateFlow<AppConfig> = _appConfig.asStateFlow()

    private val _payoutMethods = MutableStateFlow<List<PayoutMethod>>(emptyList())
    val payoutMethods: StateFlow<List<PayoutMethod>> = _payoutMethods.asStateFlow()

    private val _liveTasks = MutableStateFlow<List<RewardTask>>(emptyList())
    val liveTasks: StateFlow<List<RewardTask>> = _liveTasks.asStateFlow()

    private val _liveCategories = MutableStateFlow<List<TaskCategory>>(emptyList())
    val liveCategories: StateFlow<List<TaskCategory>> = _liveCategories.asStateFlow()

    var onBalanceUpdated: ((Int, Int) -> Unit)? = null

    private var userDocListener: ListenerRegistration? = null
    private var configListener: ListenerRegistration? = null
    private var payoutMethodsListener: ListenerRegistration? = null
    private var tasksListener: ListenerRegistration? = null
    private var categoriesListener: ListenerRegistration? = null

    private val authPrefs by lazy {
        context.getSharedPreferences("quest_rewards_auth_prefs", Context.MODE_PRIVATE)
    }

    init {
        ensureFirebaseInitialized(context)
        try {
            val savedUid = authPrefs.getString("saved_uid", null)
            val savedEmail = authPrefs.getString("saved_email", null)
            val savedName = authPrefs.getString("saved_name", null)
            val savedPhoto = authPrefs.getString("saved_photo", null)
            val savedCoins = authPrefs.getLong("saved_coins", _appConfig.value.welcomeBonusCoins)
            val savedGems = authPrefs.getLong("saved_gems", _appConfig.value.welcomeBonusGems)

            val initialFirebaseUser = auth.currentUser
            if (initialFirebaseUser != null) {
                _currentUser.value = initialFirebaseUser
                _userProfile.value = UserProfile(
                    uid = initialFirebaseUser.uid,
                    displayName = initialFirebaseUser.displayName ?: savedName ?: initialFirebaseUser.email?.substringBefore("@").orEmpty(),
                    email = initialFirebaseUser.email ?: savedEmail.orEmpty(),
                    photoUrl = initialFirebaseUser.photoUrl?.toString() ?: savedPhoto,
                    coins = savedCoins,
                    gems = savedGems
                )
                _isLoggedIn.value = true
                listenToUserProfile(initialFirebaseUser.uid)
            } else if (!savedUid.isNullOrBlank() && !savedEmail.isNullOrBlank()) {
                _userProfile.value = UserProfile(
                    uid = savedUid,
                    displayName = savedName ?: savedEmail.substringBefore("@"),
                    email = savedEmail,
                    photoUrl = savedPhoto,
                    coins = savedCoins,
                    gems = savedGems
                )
                _isLoggedIn.value = true
                listenToUserProfile(savedUid)
            }

            auth.addAuthStateListener { firebaseAuth ->
                val user = firebaseAuth.currentUser
                _currentUser.value = user

                if (user != null) {
                    _isLoggedIn.value = true
                    listenToUserProfile(user.uid)
                } else {
                    val prefUid = authPrefs.getString("saved_uid", null)
                    val prefEmail = authPrefs.getString("saved_email", null)
                    val prefName = authPrefs.getString("saved_name", null)
                    val prefPhoto = authPrefs.getString("saved_photo", null)
                    val prefCoins = authPrefs.getLong("saved_coins", _appConfig.value.welcomeBonusCoins)
                    val prefGems = authPrefs.getLong("saved_gems", _appConfig.value.welcomeBonusGems)

                    if (!prefUid.isNullOrBlank() && !prefEmail.isNullOrBlank()) {
                        if (_userProfile.value == null) {
                            _userProfile.value = UserProfile(
                                uid = prefUid,
                                displayName = prefName ?: prefEmail.substringBefore("@"),
                                email = prefEmail,
                                photoUrl = prefPhoto,
                                coins = prefCoins,
                                gems = prefGems
                            )
                        }
                        _isLoggedIn.value = true
                        listenToUserProfile(prefUid)
                    } else {
                        userDocListener?.remove()
                        userDocListener = null
                        _userProfile.value = null
                        _isUserBlocked.value = false
                        _isLoggedIn.value = false
                    }
                }
                _isCheckingSession.value = false
            }

            purgeTestUsersFromFirestore()
            listenToAppConfig()
            listenToPayoutMethods()
            listenToLiveTasks()
            listenToTaskCategories()
        } catch (e: Exception) {
            Log.w(TAG, "Services listener notice: ${e.message}")
            _isCheckingSession.value = false
        }
    }

    private fun getTodayDateKey(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return sdf.format(java.util.Date())
    }

    private fun getCurrentWeekKey(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-'W'ww", java.util.Locale.US)
        return sdf.format(java.util.Date())
    }

    private fun isTestOrDemoUser(docId: String, profile: UserProfile? = null): Boolean {
        val idLower = docId.trim().lowercase()
        val emailLower = profile?.email?.trim()?.lowercase().orEmpty()
        val nameLower = profile?.displayName?.trim()?.lowercase().orEmpty()
        return idLower == "u_testuser_questrewards_gmail_com" ||
            idLower.startsWith("u_testuser") ||
            idLower.startsWith("test_") ||
            idLower.startsWith("demo_") ||
            emailLower == "testuser.questrewards@gmail.com" ||
            emailLower.startsWith("testuser") ||
            nameLower == "test user" ||
            nameLower == "demo user"
    }

    private fun purgeTestUsersFromFirestore() {
        val knownTestDocIds = listOf(
            "u_testuser_questrewards_gmail_com",
            "test_user",
            "demo_user",
            "demo_user_1",
            "demo_user_2",
            "demo_user_3"
        )
        scope.launch {
            for (testId in knownTestDocIds) {
                try {
                    firestore.collection("users").document(testId).delete().await()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun ensureFirebaseInitialized(ctx: Context) {
        try {
            if (FirebaseApp.getApps(ctx).isEmpty()) {
                // Prefer google-services.json automatic initialization first
                val defaultApp = FirebaseApp.initializeApp(ctx)
                if (defaultApp == null) {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId("1:619517033026:android:014de17d6c6b9f095d0bdb")
                        .setApiKey("AIzaSyA7WebEkL9LdhGRAFkgRQAxblX9d62Tjaw")
                        .setProjectId("diyan-website")
                        .setDatabaseUrl("https://diyan-website-default-rtdb.firebaseio.com")
                        .setStorageBucket("diyan-website.firebasestorage.app")
                        .setGcmSenderId("619517033026")
                        .build()
                    FirebaseApp.initializeApp(ctx, options)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ensureFirebaseInitialized: ${e.message}")
        }
    }

    private fun listenToUserProfile(userId: String) {
        userDocListener?.remove()
        userDocListener = firestore.collection("users").document(userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error listening to user profile: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()) {
                    val profile = snapshot.toObject(UserProfile::class.java)
                    if (profile != null) {
                        val todayKey = getTodayDateKey()
                        val weekKey = getCurrentWeekKey()
                        val resolvedDaily = when {
                            profile.lastDailyDate == todayKey -> profile.dailyCoins
                            profile.lastDailyDate.isBlank() -> if (profile.dailyCoins > 0L) profile.dailyCoins else profile.coins
                            else -> 0L
                        }
                        val resolvedWeekly = when {
                            profile.lastWeeklyDate == weekKey -> profile.weeklyCoins
                            profile.lastWeeklyDate.isBlank() -> if (profile.weeklyCoins > 0L) profile.weeklyCoins else profile.coins
                            else -> 0L
                        }
                        val normalizedProfile = profile.copy(
                            dailyCoins = resolvedDaily,
                            weeklyCoins = resolvedWeekly,
                            lastDailyDate = todayKey,
                            lastWeeklyDate = weekKey
                        )
                        _userProfile.value = normalizedProfile
                        _isUserBlocked.value = normalizedProfile.isBlocked
                        authPrefs.edit()
                            .putLong("saved_coins", normalizedProfile.coins)
                            .putLong("saved_gems", normalizedProfile.gems)
                            .apply()
                        onBalanceUpdated?.invoke(normalizedProfile.coins.toInt(), normalizedProfile.gems.toInt())
                        Log.d(TAG, "User profile updated: ${normalizedProfile.displayName}, coins: ${normalizedProfile.coins}, daily: ${normalizedProfile.dailyCoins}, weekly: ${normalizedProfile.weeklyCoins}")
                    }
                }
            }
    }

    private fun listenToAppConfig() {
        val configRef = firestore.collection("app_config").document("settings")
        configListener = configRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(TAG, "Error listening to app_config: ${error.message}")
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists()) {
                val config = snapshot.toObject(AppConfig::class.java)
                if (config != null) {
                    _appConfig.value = config
                    Log.d(TAG, "AppConfig updated from Firestore: SuperOffer gems=${config.superOfferUnlockGems}, coins=${config.superOfferUnlockCoins}")
                }
            } else {
                Log.d(TAG, "app_config/settings does not exist yet; using default AppConfig until Admin configures it.")
            }
        }
    }

    private fun listenToPayoutMethods() {
        val methodsRef = firestore.collection("payout_methods")
        val demoSubtitles = setOf(
            "Instant Transfer to Paytm Wallet",
            "Direct Transfer to any UPI ID / VPA",
            "IMPS / NEFT Direct to Bank"
        )
        val legacyDemoIds = setOf("default_paytm", "default_upi", "default_bank")

        payoutMethodsListener = methodsRef
            .whereEqualTo("isEnabled", true)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error listening to payout_methods: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        val method = doc.toObject(PayoutMethod::class.java)?.copy(id = doc.id)
                        val isSeededDemo = doc.id in legacyDemoIds ||
                            (doc.id in setOf("PAYTM", "UPI", "BANK") && method?.subtitle in demoSubtitles)

                        if (isSeededDemo) {
                            null
                        } else {
                            method
                        }
                    }.sortedBy { it.order }
                    _payoutMethods.value = list
                    Log.d(TAG, "Loaded ${list.size} admin payout methods from Firestore")
                } else {
                    _payoutMethods.value = emptyList()
                }
            }
    }

    private fun listenToLiveTasks() {
        val tasksRef = firestore.collection("tasks")
        val legacyDemoIds = setOf("task_phonepe_01", "task_gpay_02", "task_video_ad_01", "task_survey_gaming", "task_daily_checkin", "default_install_task", "default_video_task", "default_survey_task")
        tasksListener = tasksRef
            .whereEqualTo("isEnabled", true)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error listening to tasks: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        if (doc.id in legacyDemoIds) {
                            null
                        } else {
                            doc.toObject(RewardTask::class.java)?.copy(
                                id = doc.id,
                                isCompleted = _completedTaskIds.value.contains(doc.id)
                            )
                        }
                    }.sortedBy { it.order }
                    _liveTasks.value = list
                    Log.d(TAG, "Loaded ${list.size} admin tasks from Firestore")
                } else {
                    _liveTasks.value = emptyList()
                }
            }
    }

    private fun listenToTaskCategories() {
        val catRef = firestore.collection("task_categories")
        categoriesListener = catRef
            .whereEqualTo("isEnabled", true)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error listening to task_categories: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(TaskCategory::class.java)?.copy(id = doc.id)
                    }.sortedBy { it.order }
                    _liveCategories.value = list
                    Log.d(TAG, "Loaded ${list.size} admin task categories from Firestore")
                } else {
                    _liveCategories.value = emptyList()
                }
            }
    }

    /**
     * Authenticates with Firebase using Google Sign-In ID Token.
     * Automatically registers user in Firestore, initializes welcome bonus, and prevents duplicates.
     */
    suspend fun authenticateWithGoogle(
        idToken: String?,
        email: String,
        displayName: String,
        photoUrl: String? = null
    ): Result<UserProfile> = withContext(Dispatchers.IO) {
        try {
            val cleanEmail = email.trim().lowercase()
            val cleanName = displayName.trim().ifBlank {
                cleanEmail.substringBefore("@")
                    .replace(".", " ")
                    .split(" ")
                    .joinToString(" ") { it.replaceFirstChar(Char::uppercaseChar) }
            }

            if (idToken.isNullOrBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Google ID Token missing. Ensure Google Sign-In & SHA-1 are configured in Firebase Console for diyan-website.")
                )
            }

            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val authResult = auth.signInWithCredential(credential).await()
            val firebaseUser = authResult.user
                ?: return@withContext Result.failure(IllegalStateException("Firebase authentication did not return a valid user."))

            val uid = firebaseUser.uid
            val todayKey = getTodayDateKey()
            val weekKey = getCurrentWeekKey()
            val bonusCoins = _appConfig.value.welcomeBonusCoins

            var profile = UserProfile(
                uid = uid,
                displayName = cleanName,
                email = cleanEmail,
                photoUrl = photoUrl,
                coins = bonusCoins,
                gems = _appConfig.value.welcomeBonusGems,
                dailyCoins = bonusCoins,
                weeklyCoins = bonusCoins,
                lastDailyDate = todayKey,
                lastWeeklyDate = weekKey,
                isBlocked = false
            )

            if (!isTestOrDemoUser(uid, profile)) {
                val userRef = firestore.collection("users").document(uid)
                val doc = userRef.get().await()

                if (doc.exists()) {
                    val existing = doc.toObject(UserProfile::class.java) ?: UserProfile(uid = uid)
                    val resolvedDaily = when {
                        existing.lastDailyDate == todayKey -> existing.dailyCoins
                        existing.lastDailyDate.isBlank() -> if (existing.dailyCoins > 0L) existing.dailyCoins else existing.coins
                        else -> 0L
                    }
                    val resolvedWeekly = when {
                        existing.lastWeeklyDate == weekKey -> existing.weeklyCoins
                        existing.lastWeeklyDate.isBlank() -> if (existing.weeklyCoins > 0L) existing.weeklyCoins else existing.coins
                        else -> 0L
                    }

                    profile = existing.copy(
                        uid = uid,
                        displayName = if (existing.displayName.isNotBlank()) existing.displayName else cleanName,
                        email = cleanEmail,
                        photoUrl = photoUrl ?: existing.photoUrl,
                        dailyCoins = resolvedDaily,
                        weeklyCoins = resolvedWeekly,
                        lastDailyDate = todayKey,
                        lastWeeklyDate = weekKey
                    )
                    userRef.update(
                        mapOf(
                            "displayName" to profile.displayName,
                            "email" to profile.email,
                            "photoUrl" to profile.photoUrl,
                            "dailyCoins" to profile.dailyCoins,
                            "weeklyCoins" to profile.weeklyCoins,
                            "lastDailyDate" to todayKey,
                            "lastWeeklyDate" to weekKey,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                    Log.d(TAG, "Existing user restored from Firebase: $cleanEmail, coins: ${profile.coins}")
                } else {
                    userRef.set(profile).await()
                    Log.d(TAG, "New user registered in Firebase: $cleanEmail, awarded $bonusCoins bonus coins")
                }

                authPrefs.edit()
                    .putString("saved_uid", uid)
                    .putString("saved_email", profile.email)
                    .putString("saved_name", profile.displayName)
                    .putString("saved_photo", profile.photoUrl)
                    .putLong("saved_coins", profile.coins)
                    .putLong("saved_gems", profile.gems)
                    .apply()

                listenToUserProfile(uid)
            }

            _userProfile.value = profile
            _isUserBlocked.value = profile.isBlocked
            _isLoggedIn.value = true

            Result.success(profile)
        } catch (e: Exception) {
            Log.e(TAG, "Firebase Google Auth error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun observeLeaderboard(tab: LeaderboardTab = LeaderboardTab.DAILY): Flow<List<LeaderboardEntry>> {
        val myUid = auth.currentUser?.uid ?: _userProfile.value?.uid.orEmpty()
        return firestore.collection("users")
            .limit(100)
            .snapshots()
            .map { snapshot ->
                val todayKey = getTodayDateKey()
                val weekKey = getCurrentWeekKey()

                val rawEntries = snapshot.documents.mapNotNull { doc ->
                    val profile = doc.toObject(UserProfile::class.java)
                    if (profile == null || isTestOrDemoUser(doc.id, profile)) {
                        null
                    } else {
                        val effectiveDaily = when {
                            profile.lastDailyDate == todayKey -> profile.dailyCoins
                            profile.lastDailyDate.isBlank() -> if (profile.dailyCoins > 0L) profile.dailyCoins else profile.coins
                            else -> 0L
                        }
                        val effectiveWeekly = when {
                            profile.lastWeeklyDate == weekKey -> profile.weeklyCoins
                            profile.lastWeeklyDate.isBlank() -> if (profile.weeklyCoins > 0L) profile.weeklyCoins else profile.coins
                            else -> 0L
                        }
                        val displayed = when (tab) {
                            LeaderboardTab.DAILY -> effectiveDaily
                            LeaderboardTab.WEEKLY -> effectiveWeekly
                        }

                        LeaderboardEntry(
                            rank = 0,
                            userId = doc.id,
                            displayName = profile.displayName.ifBlank { "Explorer" },
                            coins = profile.coins,
                            dailyCoins = effectiveDaily,
                            weeklyCoins = effectiveWeekly,
                            displayedCoins = displayed,
                            gems = profile.gems,
                            photoUrl = profile.photoUrl,
                            isCurrentUser = (doc.id == myUid)
                        )
                    }
                }

                val sortedEntries = rawEntries.sortedWith(
                    compareByDescending<LeaderboardEntry> { it.displayedCoins }
                        .thenByDescending { it.weeklyCoins }
                        .thenByDescending { it.coins }
                )

                sortedEntries.mapIndexed { index, entry ->
                    entry.copy(rank = index + 1)
                }
            }
    }

    suspend fun submitWithdrawal(
        method: PayoutMethod,
        accountDetail: String,
        coinsDeducted: Long,
        cashAmount: Double
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val user = _userProfile.value ?: return@withContext Result.failure(IllegalStateException("User is not logged in"))
        if (user.isBlocked) {
            return@withContext Result.failure(IllegalStateException("Account is blocked. Withdrawals are disabled."))
        }

        if (user.coins < coinsDeducted) {
            return@withContext Result.failure(IllegalStateException("Insufficient coins. Minimum required: $coinsDeducted coins."))
        }

        try {
            val withdrawalId = UUID.randomUUID().toString()
            val request = WithdrawalRequest(
                id = withdrawalId,
                userId = user.uid,
                userName = user.displayName,
                userEmail = user.email,
                methodId = method.id,
                methodTitle = method.title,
                accountDetail = accountDetail,
                coinsDeducted = coinsDeducted,
                cashAmount = cashAmount,
                status = "PENDING"
            )

            firestore.collection("withdrawals").document(withdrawalId).set(request).await()

            val newCoins = maxOf(0L, user.coins - coinsDeducted)
            firestore.collection("users").document(user.uid).update(
                mapOf(
                    "coins" to newCoins,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            _userProfile.value = user.copy(coins = newCoins)
            authPrefs.edit().putLong("saved_coins", newCoins).apply()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to submit withdrawal: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun syncBalance(coins: Long, gems: Long, earnedCoinsDelta: Long = 0L) = withContext(Dispatchers.IO) {
        val uid = auth.currentUser?.uid ?: _userProfile.value?.uid ?: return@withContext
        val currentProfile = _userProfile.value
        if (isTestOrDemoUser(uid, currentProfile)) return@withContext

        try {
            val todayKey = getTodayDateKey()
            val weekKey = getCurrentWeekKey()
            val previousCoins = currentProfile?.coins ?: coins
            val positiveDelta = when {
                earnedCoinsDelta > 0L -> earnedCoinsDelta
                coins > previousCoins -> coins - previousCoins
                else -> 0L
            }

            val baseDaily = when {
                currentProfile == null -> coins
                currentProfile.lastDailyDate == todayKey -> currentProfile.dailyCoins
                currentProfile.lastDailyDate.isBlank() -> if (currentProfile.dailyCoins > 0L) currentProfile.dailyCoins else previousCoins
                else -> 0L
            }
            val baseWeekly = when {
                currentProfile == null -> coins
                currentProfile.lastWeeklyDate == weekKey -> currentProfile.weeklyCoins
                currentProfile.lastWeeklyDate.isBlank() -> if (currentProfile.weeklyCoins > 0L) currentProfile.weeklyCoins else previousCoins
                else -> 0L
            }

            val newDaily = baseDaily + positiveDelta
            val newWeekly = baseWeekly + positiveDelta

            firestore.collection("users").document(uid).update(
                mapOf(
                    "coins" to coins,
                    "gems" to gems,
                    "dailyCoins" to newDaily,
                    "weeklyCoins" to newWeekly,
                    "lastDailyDate" to todayKey,
                    "lastWeeklyDate" to weekKey,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            _userProfile.value = currentProfile?.copy(
                coins = coins,
                gems = gems,
                dailyCoins = newDaily,
                weeklyCoins = newWeekly,
                lastDailyDate = todayKey,
                lastWeeklyDate = weekKey
            )
            authPrefs.edit()
                .putLong("saved_coins", coins)
                .putLong("saved_gems", gems)
                .apply()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to sync balance to Firestore: ${e.message}")
        }
    }

    private val _completedTaskIds = MutableStateFlow<Set<String>>(emptySet())
    val completedTaskIds: StateFlow<Set<String>> = _completedTaskIds.asStateFlow()

    fun markTaskCompleted(taskId: String) {
        val updated = _completedTaskIds.value.toMutableSet().apply { add(taskId) }
        _completedTaskIds.value = updated
        _liveTasks.value = _liveTasks.value.map { task ->
            if (task.id == taskId) task.copy(isCompleted = true) else task
        }
    }

    suspend fun getMoreTasks(): List<RewardTask> = withContext(Dispatchers.IO) {
        val completed = _completedTaskIds.value
        val live = _liveTasks.value
        live.map { it.copy(isCompleted = completed.contains(it.id)) }
    }

    fun logout() {
        authPrefs.edit().clear().apply()
        auth.signOut()
        userDocListener?.remove()
        userDocListener = null
        _currentUser.value = null
        _userProfile.value = null
        _isUserBlocked.value = false
        _isLoggedIn.value = false
    }
}
