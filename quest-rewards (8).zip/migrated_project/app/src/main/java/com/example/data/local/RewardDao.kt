package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RewardDao {

    // Balance
    @Query("SELECT * FROM user_balance WHERE id = 1")
    fun getBalance(): Flow<UserBalanceEntity?>

    @Query("SELECT * FROM user_balance WHERE id = 1")
    suspend fun getBalanceDirect(): UserBalanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBalance(balance: UserBalanceEntity)

    // Offer Sessions
    @Query("SELECT * FROM offer_sessions WHERE status != 'COMPLETED' ORDER BY id DESC LIMIT 1")
    fun getActiveOfferSession(): Flow<OfferSessionEntity?>

    @Query("SELECT * FROM offer_sessions WHERE status != 'COMPLETED' ORDER BY id DESC LIMIT 1")
    suspend fun getActiveOfferSessionDirect(): OfferSessionEntity?

    @Query("SELECT * FROM offer_sessions WHERE id = :id")
    fun getOfferSessionById(id: Long): Flow<OfferSessionEntity?>

    @Query("SELECT * FROM offer_sessions ORDER BY createdAt DESC")
    fun getAllOfferSessions(): Flow<List<OfferSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOfferSession(session: OfferSessionEntity): Long

    @Update
    suspend fun updateOfferSession(session: OfferSessionEntity)

    // Game Rounds
    @Query("SELECT * FROM game_rounds WHERE roundId = :roundId")
    suspend fun getGameRound(roundId: String): GameRoundEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertGameRound(round: GameRoundEntity)

    @Query("SELECT COUNT(*) FROM game_rounds WHERE gemAwarded = 1")
    fun getAwardedRoundsCount(): Flow<Int>

    // Transactions
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long
}
