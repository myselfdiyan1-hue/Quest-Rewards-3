const { onCall, HttpsError } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");

// Uses default Firebase Cloud environment credentials (no Service Account Private Key in code).
admin.initializeApp();
const db = admin.firestore();

function getTodayDateKey() {
  return new Date().toISOString().slice(0, 10);
}

function getCurrentWeekKey() {
  const now = new Date();
  const oneJan = new Date(now.getFullYear(), 0, 1);
  const week = Math.ceil(((now - oneJan) / 86400000 + oneJan.getDay() + 1) / 7);
  return `${now.getFullYear()}-W${String(week).padStart(2, "0")}`;
}

/**
 * Trusted server-side reward verification and credit.
 * Prevents client-side coin/gem tampering and duplicate event claims.
 */
exports.verifyAndCreditReward = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Authentication is required.");
  }

  const uid = request.auth.uid;
  const { claimId, rewardType, amount, source } = request.data || {};

  if (!claimId || typeof claimId !== "string" || claimId.length > 128) {
    throw new HttpsError("invalid-argument", "Invalid claimId.");
  }
  if (!["COINS", "GEMS"].includes(rewardType)) {
    throw new HttpsError("invalid-argument", "Invalid rewardType.");
  }
  const numericAmount = Number(amount);
  const maxAllowed = rewardType === "COINS" ? 500 : 10;
  if (!Number.isInteger(numericAmount) || numericAmount <= 0 || numericAmount > maxAllowed) {
    throw new HttpsError("invalid-argument", "Reward amount out of allowed bounds.");
  }

  const userRef = db.collection("users").doc(uid);
  const claimRef = db.collection("reward_claims").doc(`${uid}_${claimId}`);

  return db.runTransaction(async (tx) => {
    const [userSnap, claimSnap] = await Promise.all([tx.get(userRef), tx.get(claimRef)]);

    if (!userSnap.exists) {
      throw new HttpsError("not-found", "User profile not found.");
    }
    const userData = userSnap.data();
    if (userData.isBlocked === true) {
      throw new HttpsError("permission-denied", "Account is blocked.");
    }
    if (claimSnap.exists) {
      throw new HttpsError("already-exists", "Reward already claimed.");
    }

    const todayKey = getTodayDateKey();
    const weekKey = getCurrentWeekKey();
    const currentCoins = Number(userData.coins || 0);
    const currentGems = Number(userData.gems || 0);

    let newCoins = currentCoins;
    let newGems = currentGems;
    let newDaily = userData.lastDailyDate === todayKey ? Number(userData.dailyCoins || 0) : 0;
    let newWeekly = userData.lastWeeklyDate === weekKey ? Number(userData.weeklyCoins || 0) : 0;

    if (rewardType === "COINS") {
      newCoins += numericAmount;
      newDaily += numericAmount;
      newWeekly += numericAmount;
    } else {
      newGems += numericAmount;
    }

    tx.set(claimRef, {
      uid,
      claimId,
      rewardType,
      amount: numericAmount,
      source: typeof source === "string" ? source.slice(0, 100) : "REWARD",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    tx.update(userRef, {
      coins: newCoins,
      gems: newGems,
      dailyCoins: newDaily,
      weeklyCoins: newWeekly,
      lastDailyDate: todayKey,
      lastWeeklyDate: weekKey,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { coins: newCoins, gems: newGems };
  });
});

/**
 * Atomic server-side withdrawal request creation.
 * Validates account status, payout method availability, and deducts coins safely.
 */
exports.submitWithdrawalSecure = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Authentication is required.");
  }

  const uid = request.auth.uid;
  const { methodId, accountDetail } = request.data || {};

  if (!methodId || typeof methodId !== "string") {
    throw new HttpsError("invalid-argument", "Valid methodId is required.");
  }
  if (!accountDetail || typeof accountDetail !== "string" || accountDetail.trim().length < 4) {
    throw new HttpsError("invalid-argument", "Valid account details are required.");
  }

  const userRef = db.collection("users").doc(uid);
  const methodRef = db.collection("payout_methods").doc(methodId);
  const withdrawalRef = db.collection("withdrawals").doc();

  return db.runTransaction(async (tx) => {
    const [userSnap, methodSnap] = await Promise.all([tx.get(userRef), tx.get(methodRef)]);

    if (!userSnap.exists) {
      throw new HttpsError("not-found", "User profile not found.");
    }
    if (!methodSnap.exists) {
      throw new HttpsError("not-found", "Payout method not found.");
    }

    const user = userSnap.data();
    const method = methodSnap.data();

    if (user.isBlocked === true) {
      throw new HttpsError("permission-denied", "Account is blocked.");
    }
    if (method.isEnabled === false) {
      throw new HttpsError("failed-precondition", "This payout method is currently disabled.");
    }

    const requiredCoins = Number(method.minCoins || 0);
    const cashAmount = Number(method.cashAmount || 0);
    const currentCoins = Number(user.coins || 0);

    if (requiredCoins <= 0 || cashAmount <= 0) {
      throw new HttpsError("failed-precondition", "Invalid payout method configuration.");
    }
    if (currentCoins < requiredCoins) {
      throw new HttpsError("failed-precondition", `Insufficient coins. Required: ${requiredCoins}`);
    }

    const newCoins = currentCoins - requiredCoins;

    tx.set(withdrawalRef, {
      id: withdrawalRef.id,
      userId: uid,
      userName: user.displayName || "User",
      userEmail: user.email || "",
      methodId,
      methodTitle: method.title || methodId,
      accountDetail: accountDetail.trim().slice(0, 200),
      coinsDeducted: requiredCoins,
      cashAmount,
      status: "PENDING",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    tx.update(userRef, {
      coins: newCoins,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { withdrawalId: withdrawalRef.id, remainingCoins: newCoins };
  });
});
