package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.TestConfig
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class AdState {
    object Idle : AdState()
    object Loading : AdState()
    object Ready : AdState()
    data class Error(val message: String) : AdState()
    object Showing : AdState()
    data class RewardEarned(val amount: Int, val type: String) : AdState()
}

class AdMobRewardedAdManager(private val context: Context) {

    private val TAG = "AdMobRewardedAdManager"
    private var rewardedAd: RewardedAd? = null

    private val _adState = MutableStateFlow<AdState>(AdState.Idle)
    val adState: StateFlow<AdState> = _adState.asStateFlow()

    private var isAdRewardedForCurrentShow = false
    private var rewardDeliveredForCurrentAd = false
    private var isShowingAd = false
    private var lastRewardAmount = 0
    private var lastRewardType = "Coins"

    init {
        try {
            if (BuildConfig.DEBUG) {
                val reqConfig = RequestConfiguration.Builder()
                    .setTestDeviceIds(listOf(AdRequest.DEVICE_ID_EMULATOR))
                    .build()
                MobileAds.setRequestConfiguration(reqConfig)
            }
            MobileAds.initialize(context) { initializationStatus ->
                Log.d(TAG, "AdMob initialized successfully: $initializationStatus")
                loadRewardedAd()
            }
        } catch (e: Exception) {
            Log.e(TAG, "AdMob initialization error", e)
        }
    }

    fun isAdLoaded(): Boolean = rewardedAd != null

    /**
     * Loads a Rewarded Ad using TestConfig.ADMOB_REWARDED_AD_UNIT_ID
     * (Google Test Ad in debug builds, Production Ad in release builds).
     */
    fun loadRewardedAd() {
        if (_adState.value is AdState.Loading || rewardedAd != null) {
            return
        }

        _adState.value = AdState.Loading

        try {
            val adRequest = AdRequest.Builder().build()
            RewardedAd.load(
                context,
                TestConfig.ADMOB_REWARDED_AD_UNIT_ID,
                adRequest,
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        Log.d(TAG, "AdMob Rewarded Ad Loaded successfully.")
                        rewardedAd = ad
                        _adState.value = AdState.Ready
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.e(TAG, "AdMob Rewarded Ad Failed to Load (${loadAdError.code}): ${loadAdError.message}")
                        rewardedAd = null
                        _adState.value = AdState.Error(loadAdError.message)
                    }
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Exception loading Rewarded Ad", e)
            rewardedAd = null
            _adState.value = AdState.Error(e.localizedMessage ?: "Failed to load ad")
        }
    }

    /**
     * Shows the rewarded ad to the user.
     * Grants reward strictly once per ad impression and ONLY when Google Mobile Ads SDK
     * invokes the OnUserEarnedRewardListener callback.
     */
    fun showRewardedAd(
        activity: Activity,
        onAdCompletedAndClicked: (amount: Int, type: String) -> Unit,
        onAdDismissedWithoutClick: () -> Unit,
        onAdDismissed: () -> Unit,
        onAdFailedToShow: (errorMessage: String) -> Unit
    ) {
        if (activity.isFinishing || activity.isDestroyed) {
            onAdFailedToShow("Activity is not available.")
            return
        }
        if (isShowingAd) {
            onAdFailedToShow("An ad is already being displayed.")
            return
        }

        val currentAd = rewardedAd
        if (currentAd == null) {
            Log.d(TAG, "AdMob Rewarded Ad was not preloaded. Loading on demand...")
            _adState.value = AdState.Loading
            try {
                val adRequest = AdRequest.Builder().build()
                RewardedAd.load(
                    activity,
                    TestConfig.ADMOB_REWARDED_AD_UNIT_ID,
                    adRequest,
                    object : RewardedAdLoadCallback() {
                        override fun onAdLoaded(ad: RewardedAd) {
                            rewardedAd = ad
                            _adState.value = AdState.Ready
                            showAdInternal(
                                ad = ad,
                                activity = activity,
                                onAdCompleted = onAdCompletedAndClicked,
                                onAdDismissed = onAdDismissed,
                                onAdFailedToShow = onAdFailedToShow
                            )
                        }

                        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                            Log.e(TAG, "AdMob Rewarded Ad load failed on demand (${loadAdError.code}): ${loadAdError.message}")
                            rewardedAd = null
                            _adState.value = AdState.Error(loadAdError.message)
                            onAdFailedToShow(loadAdError.message)
                        }
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "Exception during on-demand Rewarded Ad load", e)
                _adState.value = AdState.Error(e.localizedMessage ?: "Ad load failed")
                onAdFailedToShow(e.localizedMessage ?: "Ad load failed")
            }
            return
        }

        showAdInternal(
            ad = currentAd,
            activity = activity,
            onAdCompleted = onAdCompletedAndClicked,
            onAdDismissed = onAdDismissed,
            onAdFailedToShow = onAdFailedToShow
        )
    }

    private fun showAdInternal(
        ad: RewardedAd,
        activity: Activity,
        onAdCompleted: (amount: Int, type: String) -> Unit,
        onAdDismissed: () -> Unit,
        onAdFailedToShow: (errorMessage: String) -> Unit
    ) {
        // Detach reference immediately so the same RewardedAd instance cannot be shown twice
        rewardedAd = null
        isShowingAd = true
        isAdRewardedForCurrentShow = false
        rewardDeliveredForCurrentAd = false
        lastRewardAmount = 0
        lastRewardType = "Reward"
        _adState.value = AdState.Showing

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "AdMob Rewarded Ad shown full screen.")
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.e(TAG, "AdMob Rewarded Ad failed to show (${adError.code}): ${adError.message}")
                isShowingAd = false
                isAdRewardedForCurrentShow = false
                _adState.value = AdState.Error(adError.message)
                onAdFailedToShow(adError.message)
                loadRewardedAd()
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "AdMob Rewarded Ad dismissed. RewardEarned: $isAdRewardedForCurrentShow")
                isShowingAd = false
                _adState.value = AdState.Idle

                if (isAdRewardedForCurrentShow && !rewardDeliveredForCurrentAd) {
                    rewardDeliveredForCurrentAd = true
                    onAdCompleted(lastRewardAmount, lastRewardType)
                } else if (!isAdRewardedForCurrentShow) {
                    onAdDismissed()
                }

                loadRewardedAd()
            }
        }

        try {
            ad.show(activity) { rewardItem ->
                if (!isAdRewardedForCurrentShow) {
                    isAdRewardedForCurrentShow = true
                    lastRewardAmount = rewardItem.amount
                    lastRewardType = rewardItem.type
                    Log.d(TAG, "AdMob Rewarded Ad: User earned reward $lastRewardAmount $lastRewardType")
                    _adState.value = AdState.RewardEarned(lastRewardAmount, lastRewardType)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception while showing Rewarded Ad", e)
            isShowingAd = false
            _adState.value = AdState.Error(e.localizedMessage ?: "Failed to show ad")
            onAdFailedToShow(e.localizedMessage ?: "Failed to show ad")
            loadRewardedAd()
        }
    }
}
