package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.firebase.PayoutMethod
import com.example.data.local.AppDatabase
import com.example.data.local.GameRoundEntity
import com.example.data.local.OfferSessionEntity
import com.example.data.local.RewardDao
import com.example.data.local.TransactionEntity
import com.example.data.local.UserBalanceEntity
import com.example.data.model.TestConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class RewardRepository(
    private val rewardDao: RewardDao,
    val firebaseManager: FirebaseManager? = null
) {

    init {
        firebaseManager?.onBalanceUpdated = { cloudCoins, cloudGems ->
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                restoreUserBalance(cloudCoins, cloudGems)
            }
        }
    }

    val balanceFlow: Flow<UserBalanceEntity> = rewardDao.getBalance().map { entity ->
        entity ?: UserBalanceEntity(id = 1, coins = TestConfig.INITIAL_COINS, gems = TestConfig.INITIAL_GEMS)
    }

    val activeOfferSessionFlow: Flow<OfferSessionEntity?> = rewardDao.getActiveOfferSession()

    val allOfferSessionsFlow: Flow<List<OfferSessionEntity>> = rewardDao.getAllOfferSessions()

    val allTransactionsFlow: Flow<List<TransactionEntity>> = rewardDao.getAllTransactions()

    suspend fun ensureInitialBalance() {
        val existing = rewardDao.getBalanceDirect()
        if (existing == null) {
            val profile = firebaseManager?.userProfile?.value
            val initialCoins = profile?.coins?.toInt() ?: TestConfig.INITIAL_COINS
            val initialGems = profile?.gems?.toInt() ?: TestConfig.INITIAL_GEMS
            rewardDao.insertBalance(
                UserBalanceEntity(
                    id = 1,
                    coins = initialCoins,
                    gems = initialGems
                )
            )
        }
    }

    suspend fun getBalanceDirect(): UserBalanceEntity {
        return rewardDao.getBalanceDirect() ?: UserBalanceEntity(
            id = 1,
            coins = firebaseManager?.userProfile?.value?.coins?.toInt() ?: TestConfig.INITIAL_COINS,
            gems = firebaseManager?.userProfile?.value?.gems?.toInt() ?: TestConfig.INITIAL_GEMS
        ).also { rewardDao.insertBalance(it) }
    }

    suspend fun awardGameRoundGem(roundId: String): Boolean {
        val existingRound = rewardDao.getGameRound(roundId)
        if (existingRound != null && existingRound.gemAwarded) {
            return false
        }

        val current = getBalanceDirect()

        val newGems = current.gems + TestConfig.GEM_REWARD_PER_ROUND
        val updated = current.copy(gems = newGems)
        rewardDao.insertBalance(updated)
        rewardDao.insertGameRound(
            GameRoundEntity(roundId = roundId, completed = true, gemAwarded = true)
        )
        rewardDao.insertTransaction(
            TransactionEntity(
                title = "Image Finder Win",
                type = "GEMS",
                amount = TestConfig.GEM_REWARD_PER_ROUND,
                description = "Earned 1 Gem by solving Round #$roundId"
            )
        )

        firebaseManager?.syncBalance(updated.coins.toLong(), updated.gems.toLong())
        return true
    }

    /**
     * Unlocks the Super Offer by spending required gems and coins (dynamically customized from Firebase Admin Config).
     */
    suspend fun unlockSuperOffer(initialPackagesSnapshot: String): Result<Long> {
        val current = getBalanceDirect()
        val config = firebaseManager?.appConfig?.value
        val reqGems = config?.superOfferUnlockGems?.toInt() ?: TestConfig.SUPER_OFFER_REQUIRED_GEMS
        val reqCoins = config?.superOfferUnlockCoins?.toInt() ?: 0

        if (current.gems < reqGems) {
            return Result.failure(IllegalStateException("You need $reqGems Gems to unlock this Super Offer."))
        }
        if (current.coins < reqCoins) {
            return Result.failure(IllegalStateException("You need $reqCoins Coins to unlock this Super Offer."))
        }

        val active = rewardDao.getActiveOfferSessionDirect()
        if (active != null) {
            return Result.success(active.id)
        }

        // Deduct gems & coins
        val updatedGems = current.gems - reqGems
        val updatedCoins = current.coins - reqCoins
        val updated = current.copy(coins = updatedCoins, gems = updatedGems)
        rewardDao.insertBalance(updated)

        rewardDao.insertTransaction(
            TransactionEntity(
                title = "Super Offer Unlocked",
                type = "GEMS",
                amount = -reqGems,
                description = "Spent $reqGems Gems & $reqCoins Coins to unlock Super Offer"
            )
        )

        firebaseManager?.syncBalance(updatedCoins.toLong(), updatedGems.toLong())

        val newSession = OfferSessionEntity(
            status = "IN_PROGRESS",
            adWatched = false,
            installedPackagesSnapshot = initialPackagesSnapshot,
            observedUsageSeconds = 0,
            requiredUsageSeconds = TestConfig.REQUIRED_USAGE_SECONDS,
            currentStep = 1,
            coinsRewarded = false,
            createdAt = System.currentTimeMillis()
        )
        val sessionId = rewardDao.insertOfferSession(newSession)
        return Result.success(sessionId)
    }

    suspend fun getOfferSession(id: Long): Flow<OfferSessionEntity?> {
        return rewardDao.getOfferSessionById(id)
    }

    suspend fun recordAdWatchedOnly(sessionId: Long) {
        val session = rewardDao.getActiveOfferSessionDirect() ?: return
        if (session.id != sessionId) return
        val updated = session.copy(
            adWatched = true,
            adClicked = false,
            currentStep = 1
        )
        rewardDao.updateOfferSession(updated)
    }

    suspend fun recordAdWatchedAndClicked(sessionId: Long) {
        val session = rewardDao.getActiveOfferSessionDirect() ?: return
        if (session.id != sessionId) return
        val updated = session.copy(
            adWatched = true,
            adClicked = true,
            currentStep = if (session.currentStep <= 1) 2 else session.currentStep
        )
        rewardDao.updateOfferSession(updated)
    }

    suspend fun markAdWatched(sessionId: Long) {
        recordAdWatchedAndClicked(sessionId)
    }

    suspend fun setTargetApplication(sessionId: Long, packageName: String, appName: String) {
        val session = rewardDao.getActiveOfferSessionDirect() ?: return
        if (session.id != sessionId) return
        val updated = session.copy(
            targetPackageName = packageName,
            targetAppName = appName,
            installationObserved = true,
            currentStep = if (session.currentStep <= 2) 3 else session.currentStep
        )
        rewardDao.updateOfferSession(updated)
    }

    suspend fun updateUsageProgress(sessionId: Long, observedSeconds: Long) {
        val session = rewardDao.getActiveOfferSessionDirect() ?: return
        if (session.id != sessionId) return
        val cappedSeconds = observedSeconds.coerceAtMost(session.requiredUsageSeconds)
        val updatedStep = if (cappedSeconds >= session.requiredUsageSeconds) 4 else 3
        val updated = session.copy(
            observedUsageSeconds = cappedSeconds,
            currentStep = updatedStep
        )
        rewardDao.updateOfferSession(updated)
    }

    suspend fun completeOfferAndClaimCoins(sessionId: Long): Result<Int> {
        val session = rewardDao.getActiveOfferSessionDirect()
            ?: return Result.failure(IllegalStateException("No active offer session found."))

        if (session.id != sessionId) {
            return Result.failure(IllegalStateException("Session ID mismatch."))
        }

        if (session.coinsRewarded) {
            return Result.failure(IllegalStateException("Offer reward has already been claimed."))
        }

        if (!session.adWatched) {
            return Result.failure(IllegalStateException("Video ad step has not been completed."))
        }

        if (session.targetPackageName.isNullOrEmpty() || !session.installationObserved) {
            return Result.failure(IllegalStateException("Target app installation has not been observed."))
        }

        if (session.observedUsageSeconds < session.requiredUsageSeconds) {
            return Result.failure(IllegalStateException("Required usage time (120s) not yet reached."))
        }

        val currentBalance = getBalanceDirect()
        val newCoins = currentBalance.coins + TestConfig.SUPER_OFFER_COIN_REWARD
        val updated = currentBalance.copy(coins = newCoins)
        rewardDao.insertBalance(updated)

        val completedSession = session.copy(
            status = "COMPLETED",
            coinsRewarded = true,
            currentStep = 4,
            completedAt = System.currentTimeMillis()
        )
        rewardDao.updateOfferSession(completedSession)

        rewardDao.insertTransaction(
            TransactionEntity(
                title = "Super Offer Completed",
                type = "COINS",
                amount = TestConfig.SUPER_OFFER_COIN_REWARD,
                description = "Claimed reward for completing all 4 steps of ${session.targetAppName ?: "App"} offer"
            )
        )

        firebaseManager?.syncBalance(
            coins = newCoins.toLong(),
            gems = updated.gems.toLong(),
            earnedCoinsDelta = TestConfig.SUPER_OFFER_COIN_REWARD.toLong()
        )
        return Result.success(TestConfig.SUPER_OFFER_COIN_REWARD)
    }

    /**
     * Deducts coins and submits a payout request to Firebase Firestore.
     */
    suspend fun requestPayout(payoutMethod: PayoutMethod, inrAmount: Double, coinsNeeded: Long, accountDetail: String): Result<Unit> {
        val currentBalance = getBalanceDirect()
        if (currentBalance.coins < coinsNeeded) {
            return Result.failure(IllegalStateException("Not enough coins! Need $coinsNeeded coins."))
        }

        val fm = firebaseManager ?: return Result.failure(IllegalStateException("Firebase Manager not ready"))
        val result = fm.submitWithdrawal(
            method = payoutMethod,
            accountDetail = accountDetail,
            coinsDeducted = coinsNeeded,
            cashAmount = inrAmount
        )

        if (result.isSuccess) {
            val newCoins = (currentBalance.coins - coinsNeeded).toInt()
            rewardDao.insertBalance(currentBalance.copy(coins = newCoins))
            rewardDao.insertTransaction(
                TransactionEntity(
                    title = "Payout: ₹$inrAmount (${payoutMethod.title})",
                    type = "COINS",
                    amount = -coinsNeeded.toInt(),
                    description = "Transferred ₹$inrAmount to $accountDetail via ${payoutMethod.title}"
                )
            )
        }
        return result
    }

    suspend fun awardTaskCoins(taskId: String, taskTitle: String, coins: Int, description: String): Int {
        val current = getBalanceDirect()
        val newCoins = current.coins + coins
        val updated = current.copy(coins = newCoins)
        rewardDao.insertBalance(updated)

        rewardDao.insertTransaction(
            TransactionEntity(
                title = "Task: $taskTitle",
                type = "COINS",
                amount = coins,
                description = description
            )
        )

        firebaseManager?.syncBalance(
            coins = newCoins.toLong(),
            gems = updated.gems.toLong(),
            earnedCoinsDelta = coins.toLong()
        )
        return newCoins
    }

    suspend fun restoreUserBalance(coins: Int, gems: Int) {
        val current = getBalanceDirect()
        val restoredCoins = maxOf(current.coins, coins)
        val restoredGems = maxOf(current.gems, gems)
        rewardDao.insertBalance(UserBalanceEntity(id = 1, coins = restoredCoins, gems = restoredGems))
    }

    suspend fun resetTestData() {
        rewardDao.insertBalance(UserBalanceEntity(id = 1, coins = 0, gems = 0))
    }
}
