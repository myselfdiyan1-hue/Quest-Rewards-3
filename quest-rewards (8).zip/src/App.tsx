import { ShieldCheck, Smartphone, ExternalLink, Coins, Lock } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-10">
      <div className="max-w-4xl mx-auto space-y-6">
        <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-indigo-400">
              Quest Rewards
            </p>
            <h1 className="text-2xl md:text-3xl font-bold text-white mt-1">
              Firebase Migration &amp; AdMob Production Hub
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Target Project: <code className="text-sky-400">diyan-website</code> &bull; Package:{' '}
              <code className="text-sky-400">com.aistudio.questrewards.jqeqdg</code>
            </p>
          </div>
          <a
            href="/admin_panel.html"
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 px-5 py-3 text-sm font-semibold text-white transition-colors"
          >
            Open Admin Panel
            <ExternalLink className="w-4 h-4" />
          </a>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 space-y-3">
            <div className="flex items-center gap-2 text-sky-400 font-semibold">
              <Smartphone className="w-5 h-5" />
              <h2>Firebase Project Target</h2>
            </div>
            <dl className="text-sm space-y-1.5 text-slate-300">
              <div className="flex justify-between gap-2">
                <dt className="text-slate-400">Project ID</dt>
                <dd className="font-mono text-white">diyan-website</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-slate-400">Auth Domain</dt>
                <dd className="font-mono text-white">diyan-website.firebaseapp.com</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-slate-400">Sender ID</dt>
                <dd className="font-mono text-white">619517033026</dd>
              </div>
            </dl>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold">
              <Coins className="w-5 h-5" />
              <h2>AdMob Production IDs</h2>
            </div>
            <dl className="text-xs space-y-1.5 text-slate-300">
              <div className="flex justify-between gap-2">
                <dt className="text-slate-400">App ID</dt>
                <dd className="font-mono text-white">ca-app-pub-8516623795008666~7322569396</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-slate-400">Rewarded</dt>
                <dd className="font-mono text-white">ca-app-pub-8516623795008666/6563200658</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-slate-400">Interstitial</dt>
                <dd className="font-mono text-white">ca-app-pub-8516623795008666/3296130216</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-slate-400">Banner</dt>
                <dd className="font-mono text-white">ca-app-pub-8516623795008666/8005321012</dd>
              </div>
            </dl>
          </section>
        </div>

        <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 space-y-3">
          <div className="flex items-center gap-2 text-amber-400 font-semibold">
            <ShieldCheck className="w-5 h-5" />
            <h2>Security &amp; Console Checklist</h2>
          </div>
          <ul className="text-sm text-slate-300 space-y-2 list-disc list-inside">
            <li>
              Add Debug &amp; Release SHA-1 fingerprints in Firebase Console for{' '}
              <code className="text-sky-400">com.aistudio.questrewards.jqeqdg</code>, enable Google Sign-In &amp; Email/Password, and re-download{' '}
              <code className="text-sky-400">google-services.json</code>.
            </li>
            <li>
              Deploy hardened <code className="text-sky-400">firestore.rules</code> to{' '}
              <code className="text-sky-400">diyan-website</code> and create{' '}
              <code className="text-sky-400">admins/&#123;ADMIN_UID&#125;</code> in Firestore Console.
            </li>
            <li>
              Debug builds automatically use Google Test Ad Unit IDs; release builds automatically use your Production Ad Unit IDs.
            </li>
          </ul>
        </section>

        <footer className="flex items-center gap-2 text-xs text-slate-500">
          <Lock className="w-3.5 h-3.5" />
          <span>No private service account keys are stored in client or web files.</span>
        </footer>
      </div>
    </div>
  );
}
