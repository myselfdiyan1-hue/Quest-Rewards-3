package com.example.ui.tasks

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdMobRewardedAdManager
import com.example.data.firebase.FirebaseManager
import com.example.data.firebase.RewardTask
import com.example.data.firebase.TaskCategory
import com.example.data.local.UserBalanceEntity
import com.example.data.model.TestConfig
import com.example.data.repository.RewardRepository
import com.example.ui.components.GoldCoinIcon
import com.example.ui.components.bounceClick
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.SecondaryText
import com.example.util.findActivity
import kotlinx.coroutines.launch

@Composable
fun MoreTasksScreen(
    rewardRepository: RewardRepository,
    firebaseManager: FirebaseManager,
    adMobRewardedAdManager: AdMobRewardedAdManager,
    onNavigateToSuperOffer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val activity = context.findActivity()

    val balance by rewardRepository.balanceFlow.collectAsStateWithLifecycle(
        initialValue = UserBalanceEntity(id = 1, coins = TestConfig.INITIAL_COINS, gems = TestConfig.INITIAL_GEMS)
    )

    // Dynamic tasks and categories straight from Admin Panel (Firebase Firestore)
    val liveTasks by firebaseManager.liveTasks.collectAsStateWithLifecycle()
    val liveCategories by firebaseManager.liveCategories.collectAsStateWithLifecycle()

    var selectedCategory by remember { mutableStateOf("ALL") }

    // Active Task Dialog State
    var surveyTaskToOpen by remember { mutableStateOf<RewardTask?>(null) }
    var appTaskToOpen by remember { mutableStateOf<RewardTask?>(null) }

    // Dynamically build category tabs from Admin Panel
    val categories = remember(liveCategories, liveTasks) {
        val list = mutableListOf<Pair<String, String>>()
        list.add(Pair("ALL", "All Tasks"))

        // 1. Categories configured in Firestore task_categories collection by Admin
        liveCategories.filter { it.isEnabled }.forEach { cat ->
            list.add(Pair(cat.id, cat.name.ifBlank { cat.id }))
        }

        // 2. Any additional categories found in active tasks that aren't already listed
        val existingIds = list.map { it.first.uppercase() }.toSet()
        liveTasks.map { it.category }.distinct().forEach { catStr ->
            if (catStr.isNotBlank() && catStr.uppercase() !in existingIds) {
                val formattedName = catStr.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
                list.add(Pair(catStr, formattedName))
            }
        }
        list
    }

    val filteredTasks = if (selectedCategory == "ALL") {
        liveTasks
    } else {
        liveTasks.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MainBackground)
            .testTag("tasks_screen")
    ) {
        // Top App Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HeaderBackground,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Tasks",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = PrimaryText
                    )
                    Text(
                        text = "Complete missions to earn real coins",
                        fontSize = 11.sp,
                        color = SecondaryText
                    )
                }

                // Balance Chip
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFFEF3C7))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    GoldCoinIcon(size = 16.dp)
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "${balance.coins}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF92400E)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(10.dp))

                // Super Offer Spotlight Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .bounceClick { onNavigateToSuperOffer() }
                        .testTag("tasks_super_offer_banner"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6), Color(0xFF6366F1))
                                )
                            )
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = Color(0xFFFBBF24),
                                    modifier = Modifier.size(30.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "SUPER OFFER",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFFFBBF24),
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF22C55E))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "HIGH REWARD",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Text(
                                    text = "Earn +${TestConfig.SUPER_OFFER_COIN_REWARD} Coins per completion",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            Icon(
                                imageVector = Icons.Filled.KeyboardArrowRight,
                                contentDescription = "Open",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            // Dynamic Category Filter Pills from Admin Panel
            if (categories.size > 1) {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(categories) { (id, label) ->
                            val isSelected = selectedCategory == id
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (isSelected) PrimaryBlue else Color(0xFFE2E8F0)
                                    )
                                    .clickable { selectedCategory = id }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else PrimaryText
                                )
                            }
                        }
                    }
                }
            }

            // Tasks List or Clean Empty State (NO DEMO DATA)
            if (filteredTasks.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp)
                            .testTag("tasks_empty_state_card"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        border = BorderStroke(1.dp, BorderSubtle),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFF1F5F9)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AssignmentTurnedIn,
                                    contentDescription = null,
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "No Tasks Available",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryText
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Tasks added from Admin Panel will appear here automatically.",
                                fontSize = 13.sp,
                                color = SecondaryText,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            } else {
                items(filteredTasks, key = { it.id }) { task ->
                    TaskCard(
                        task = task,
                        onCompleteClick = {
                            when (task.category.uppercase()) {
                                "VIDEO" -> {
                                    if (activity != null) {
                                        adMobRewardedAdManager.loadRewardedAd()
                                        adMobRewardedAdManager.showRewardedAd(
                                            activity = activity,
                                            onAdCompletedAndClicked = { _, _ ->
                                                coroutineScope.launch {
                                                    rewardRepository.awardTaskCoins(
                                                        taskId = task.id,
                                                        taskTitle = task.title,
                                                        coins = task.rewardCoins,
                                                        description = "Completed video sponsor task: ${task.title}"
                                                    )
                                                    firebaseManager.markTaskCompleted(task.id)
                                                    Toast.makeText(
                                                        context,
                                                        "🎉 +${task.rewardCoins} Coins added to your wallet!",
                                                        Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                            },
                                            onAdDismissedWithoutClick = {
                                                coroutineScope.launch {
                                                    rewardRepository.awardTaskCoins(
                                                        taskId = task.id,
                                                        taskTitle = task.title,
                                                        coins = task.rewardCoins,
                                                        description = "Completed video task: ${task.title}"
                                                    )
                                                    firebaseManager.markTaskCompleted(task.id)
                                                }
                                            },
                                            onAdDismissed = {},
                                            onAdFailedToShow = {
                                                coroutineScope.launch {
                                                    rewardRepository.awardTaskCoins(
                                                        taskId = task.id,
                                                        taskTitle = task.title,
                                                        coins = task.rewardCoins,
                                                        description = "Completed video sponsor task: ${task.title}"
                                                    )
                                                    firebaseManager.markTaskCompleted(task.id)
                                                    Toast.makeText(
                                                        context,
                                                        "🎉 +${task.rewardCoins} Coins added to your wallet!",
                                                        Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                            }
                                        )
                                    }
                                }
                                "SURVEY" -> {
                                    surveyTaskToOpen = task
                                }
                                "DAILY" -> {
                                    coroutineScope.launch {
                                        rewardRepository.awardTaskCoins(
                                            taskId = task.id,
                                            taskTitle = task.title,
                                            coins = task.rewardCoins,
                                            description = "Claimed daily streak bonus"
                                        )
                                        firebaseManager.markTaskCompleted(task.id)
                                        Toast.makeText(
                                            context,
                                            "🎉 +${task.rewardCoins} Coins claimed for today!",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                                else -> {
                                    // App Install or other tasks
                                    appTaskToOpen = task
                                }
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Survey Task Dialog
    if (surveyTaskToOpen != null) {
        val task = surveyTaskToOpen!!
        var currentAnswer by remember { mutableIntStateOf(0) }

        Dialog(onDismissRequest = { surveyTaskToOpen = null }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Quick Survey",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryText
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = task.description.ifBlank { "Which type of mobile rewards do you prefer most?" },
                        fontSize = 13.sp,
                        color = SecondaryText
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val surveyOptions = listOf(
                        "Instant UPI Cash transfer",
                        "Paytm Wallet balance",
                        "Direct Bank Account NEFT/IMPS",
                        "Game Currency & Vouchers"
                    )

                    surveyOptions.forEachIndexed { index, option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (currentAnswer == index) Color(0xFFEFF6FF) else Color(0xFFF8FAFC))
                                .clickable { currentAnswer = index }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (currentAnswer == index) Icons.Filled.RadioButtonChecked else Icons.Filled.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (currentAnswer == index) PrimaryBlue else SecondaryText,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = option,
                                fontSize = 13.sp,
                                fontWeight = if (currentAnswer == index) FontWeight.Bold else FontWeight.Normal,
                                color = PrimaryText
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                rewardRepository.awardTaskCoins(
                                    taskId = task.id,
                                    taskTitle = task.title,
                                    coins = task.rewardCoins,
                                    description = "Completed survey: ${task.title}"
                                )
                                firebaseManager.markTaskCompleted(task.id)
                                surveyTaskToOpen = null
                                Toast.makeText(
                                    context,
                                    "🎉 Survey submitted! +${task.rewardCoins} Coins added to your wallet!",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Text("Submit & Claim +${task.rewardCoins} Coins", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // App Install Task Dialog
    if (appTaskToOpen != null) {
        val task = appTaskToOpen!!

        Dialog(onDismissRequest = { appTaskToOpen = null }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = task.title,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryText
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = task.description,
                        fontSize = 13.sp,
                        color = SecondaryText
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Instructions:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryText
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val steps = listOf(
                        "Click 'Download App' to install",
                        "Open the app and browse for 30-60 seconds",
                        "Return here to claim your +${task.rewardCoins} Coins"
                    )

                    steps.forEachIndexed { i, step ->
                        Row(modifier = Modifier.padding(vertical = 3.dp)) {
                            Text(
                                text = "${i + 1}. ",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryBlue
                            )
                            Text(
                                text = step,
                                fontSize = 12.sp,
                                color = SecondaryText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    if (task.actionUrl.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                try {
                                    val intent = android.content.Intent(
                                        android.content.Intent.ACTION_VIEW,
                                        android.net.Uri.parse(task.actionUrl)
                                    )
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Could not open link: ${task.actionUrl}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, PrimaryBlue)
                        ) {
                            Text("Open Task Link / App", color = PrimaryBlue, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                rewardRepository.awardTaskCoins(
                                    taskId = task.id,
                                    taskTitle = task.title,
                                    coins = task.rewardCoins,
                                    description = "Completed task: ${task.title}"
                                )
                                firebaseManager.markTaskCompleted(task.id)
                                appTaskToOpen = null
                                Toast.makeText(
                                    context,
                                    "🎉 Task completed! +${task.rewardCoins} Coins added to your wallet!",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Text("Complete & Claim +${task.rewardCoins} Coins", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TaskCard(
    task: RewardTask,
    onCompleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClick { if (!task.isCompleted) onCompleteClick() }
            .testTag("task_card_${task.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category Icon with colored background
            val (icon, bgCol, iconCol) = when (task.category.uppercase()) {
                "INSTALL" -> Triple(Icons.Filled.ShoppingBag, Color(0xFFEFF6FF), PrimaryBlue)
                "VIDEO" -> Triple(Icons.Filled.OndemandVideo, Color(0xFFFEF2F2), Color(0xFFDC2626))
                "SURVEY" -> Triple(Icons.Filled.Poll, Color(0xFFFAF5FF), Color(0xFF9333EA))
                "DAILY" -> Triple(Icons.Filled.Stars, Color(0xFFFEF3C7), Color(0xFFD97706))
                "SOCIAL" -> Triple(Icons.Filled.Send, Color(0xFFECFDF5), Color(0xFF059669))
                else -> Triple(Icons.Filled.Games, Color(0xFFF1F5F9), PrimaryBlue)
            }

            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bgCol),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconCol,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryText
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = task.description,
                    fontSize = 11.sp,
                    color = SecondaryText,
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Reward Tag
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GoldCoinIcon(size = 14.dp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "+${task.rewardCoins} Coins",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFD97706)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Action / Status Button
            if (task.isCompleted) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFDCFCE7))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF16A34A),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Done",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                }
            } else {
                Button(
                    onClick = onCompleteClick,
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("task_action_btn_${task.id}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (task.category.uppercase() == "DAILY") Color(0xFF059669) else PrimaryBlue
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)
                ) {
                    Text(
                        text = when (task.category.uppercase()) {
                            "DAILY" -> "Claim"
                            "VIDEO" -> "Watch"
                            "SURVEY" -> "Start"
                            else -> "Start"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
