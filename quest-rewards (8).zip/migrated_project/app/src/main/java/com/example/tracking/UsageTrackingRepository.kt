package com.example.tracking

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import com.example.data.model.TestConfig

class UsageTrackingRepository(private val context: Context) {

    private val usageStatsManager: UsageStatsManager? by lazy {
        context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
    }

    /**
     * Checks if Usage Access permission is granted via AppOpsManager.
     */
    fun hasUsageAccessPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Creates an intent to navigate directly to the system Usage Access settings.
     */
    fun getUsageAccessSettingsIntent(): Intent {
        return Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Computes foreground usage duration in seconds for the target package
     * between startTimeMs and endTimeMs using UsageEvents.
     *
     * Conservative rules:
     * - Only counts intervals between ACTIVITY_RESUMED (or MOVE_TO_FOREGROUND) and ACTIVITY_PAUSED/STOPPED
     * - Discards negative or unreasonable timestamps
     * - Ignores own app and unrelated apps
     */
    fun calculateTargetAppForegroundUsageSeconds(
        targetPackageName: String,
        startTimeMs: Long,
        endTimeMs: Long = System.currentTimeMillis()
    ): Long {
        if (!hasUsageAccessPermission() || usageStatsManager == null) {
            return 0L
        }

        val safeStartTime = (startTimeMs - 60_000).coerceAtLeast(0) // 1 min buffer for clock drift
        val safeEndTime = endTimeMs.coerceAtLeast(safeStartTime)

        val usageEvents: UsageEvents = try {
            usageStatsManager?.queryEvents(safeStartTime, safeEndTime) ?: return 0L
        } catch (e: Exception) {
            return 0L
        }

        var totalForegroundMillis = 0L
        var sessionStartMillis: Long? = null

        val event = UsageEvents.Event()
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)

            if (event.packageName != targetPackageName) {
                // If another app comes to foreground, end current session if open
                if (sessionStartMillis != null && (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                            || event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND)) {
                    val delta = event.timeStamp - sessionStartMillis
                    if (delta in 1..86_400_000) {
                        totalForegroundMillis += delta
                    }
                    sessionStartMillis = null
                }
                continue
            }

            when (event.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED,
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    if (sessionStartMillis == null) {
                        sessionStartMillis = event.timeStamp
                    }
                }

                UsageEvents.Event.ACTIVITY_PAUSED,
                UsageEvents.Event.ACTIVITY_STOPPED,
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (sessionStartMillis != null) {
                        val delta = event.timeStamp - sessionStartMillis
                        if (delta in 1..86_400_000) {
                            totalForegroundMillis += delta
                        }
                        sessionStartMillis = null
                    }
                }
            }
        }

        // If still in foreground when check occurs
        if (sessionStartMillis != null) {
            val delta = safeEndTime - sessionStartMillis
            if (delta in 1..86_400_000) {
                totalForegroundMillis += delta
            }
        }

        val seconds = totalForegroundMillis / 1000L
        return seconds.coerceAtLeast(0L)
    }

    /**
     * Fallback inspection using queryUsageStats in case events were pruned or delayed by OS.
     */
    fun getFallbackUsageStatsSeconds(targetPackageName: String, startTimeMs: Long): Long {
        if (!hasUsageAccessPermission() || usageStatsManager == null) return 0L
        return try {
            val statsList = usageStatsManager?.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                startTimeMs,
                System.currentTimeMillis()
            ) ?: emptyList()
            val targetStats = statsList.firstOrNull { it.packageName == targetPackageName }
            if (targetStats != null) {
                (targetStats.totalTimeInForeground / 1000L).coerceAtLeast(0L)
            } else {
                0L
            }
        } catch (e: Exception) {
            0L
        }
    }
}
