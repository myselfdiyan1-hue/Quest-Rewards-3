# Quest Rewards — Android App & Admin Panel

Native Android application built with **Kotlin** and **Jetpack Compose** (MVVM + Room + Firebase + Google AdMob), paired with a real-time HTML **Admin Panel**.

---

## Firebase Configuration (`diyan-website`)

- **Project ID:** `diyan-website`
- **Auth Domain:** `diyan-website.firebaseapp.com`
- **Database URL:** `https://diyan-website-default-rtdb.firebaseio.com`
- **Storage Bucket:** `diyan-website.firebasestorage.app`
- **Messaging Sender ID:** `619517033026`
- **Android Package Name:** `com.aistudio.questrewards.jqeqdg`

### Required Firebase Console Setup Before Running Release/Auth
1. Open **Firebase Console → Project Settings (`diyan-website`) → Your apps → `com.aistudio.questrewards.jqeqdg`**.
2. Add your **Debug** and **Release** SHA-1 (and SHA-256) fingerprints, then re-download `google-services.json` into `app/google-services.json` so `oauth_client` is populated.
3. Open **Authentication → Sign-in method** and enable **Google** and **Email/Password**.
4. Deploy `firestore.rules` to `diyan-website` (`firebase deploy --only firestore:rules --project diyan-website`).
5. Add your Admin UID document in Firestore at `admins/{YOUR_ADMIN_UID}` (or verify `myselfdiyan1@gmail.com`).

---

## Google AdMob Integration

Configured in `AndroidManifest.xml` and `TestConfig.kt`:
- **Production App ID:** `ca-app-pub-8516623795008666~7322569396`
- **Debug Builds (`BuildConfig.DEBUG == true`):** Automatically use Google Official Test Ad Unit IDs (Rewarded `.../5224354917`, Interstitial `.../1033173712`, Banner `.../6300978111`).
- **Release Builds (`BuildConfig.DEBUG == false`):** Automatically use Production Ad Unit IDs:
  - Rewarded: `ca-app-pub-8516623795008666/6563200658`
  - Interstitial: `ca-app-pub-8516623795008666/3296130216`
  - Banner: `ca-app-pub-8516623795008666/8005321012`

---

## Building the APK in Android Studio / CLI

Open the `migrated_project/` folder in Android Studio, allow Gradle Sync to finish, and run:
```bash
./gradlew assembleDebug
```
Output APK path:
```
app/build/outputs/apk/debug/app-debug.apk
```
For Play Store release builds:
```bash
./gradlew bundleRelease
```
