package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GemQuest Rewards Design Tokens
val MainBackground = Color(0xFFEEF1FF)
val HeaderBackground = Color(0xFFF8F8FC)
val CardWhite = Color(0xFFFFFFFF)
val PrimaryBlue = Color(0xFF385BEE)
val SecondaryBlue = Color(0xFF6A80F2)
val Lavender = Color(0xFFA8B0F4)
val PurpleAccent = Color(0xFF852BEE)
val OrangeAccent = Color(0xFFFFA51F)
val YellowAccent = Color(0xFFFFD52E)
val CoinGold = Color(0xFFF5B51B)
val GemCyan = Color(0xFF20BDF0)
val PrimaryText = Color(0xFF17192B)
val SecondaryText = Color(0xFF777D96)
val BorderSubtle = Color(0xFFE2E7FA)
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val SurfaceVariant = Color(0xFFF1F4FD)
