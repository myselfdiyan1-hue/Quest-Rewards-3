package com.example.data.firebase

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val uid: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val coins: Long = 50L,
    val gems: Long = 5L,
    val dailyCoins: Long = 0L,
    val weeklyCoins: Long = 0L,
    val lastDailyDate: String = "",
    val lastWeeklyDate: String = "",
    val isBlocked: Boolean = false,
    @ServerTimestamp val createdAt: Date? = null,
    @ServerTimestamp val updatedAt: Date? = null
)

@IgnoreExtraProperties
data class AppConfig(
    val superOfferUnlockCoins: Long = 0L,
    val superOfferUnlockGems: Long = 2L,
    val isSuperOfferEnabled: Boolean = true,
    val minWithdrawalCoins: Long = 1000L,
    val conversionRateText: String = "1,000 Coins = ₹10 INR",
    val welcomeBonusCoins: Long = 50L,
    val welcomeBonusGems: Long = 5L
)

@IgnoreExtraProperties
data class PayoutMethod(
    @DocumentId val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val iconType: String = "WALLET", // PAYTM, UPI, BANK, WALLET, GIFT
    val minCoins: Long = 1000L,
    val cashAmount: Double = 10.0,
    val currency: String = "₹",
    val instructions: String = "",
    val inputLabel: String = "Account Details",
    val inputPlaceholder: String = "Enter account number or UPI ID",
    val isEnabled: Boolean = true,
    val order: Long = 0L
)

@IgnoreExtraProperties
data class WithdrawalRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val methodId: String = "",
    val methodTitle: String = "",
    val accountDetail: String = "",
    val coinsDeducted: Long = 0L,
    val cashAmount: Double = 0.0,
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    @ServerTimestamp val createdAt: Date? = null
)

enum class LeaderboardTab(val label: String, val subtitle: String) {
    DAILY("Daily", "Today's Earning"),
    WEEKLY("Weekly", "This Week's Earning")
}

data class LeaderboardEntry(
    val rank: Int = 0,
    val userId: String = "",
    val displayName: String = "",
    val coins: Long = 0L,
    val dailyCoins: Long = 0L,
    val weeklyCoins: Long = 0L,
    val displayedCoins: Long = 0L,
    val gems: Long = 0L,
    val photoUrl: String? = null,
    val isCurrentUser: Boolean = false
)

@IgnoreExtraProperties
data class RewardTask(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val rewardCoins: Int = 50,
    val category: String = "INSTALL", // INSTALL, SURVEY, VIDEO, DAILY, SOCIAL
    val iconType: String = "APP",
    val actionUrl: String = "",
    val isEnabled: Boolean = true,
    val order: Long = 0L,
    val isCompleted: Boolean = false,
    val progress: Float = 0f
)

@IgnoreExtraProperties
data class TaskCategory(
    @DocumentId val id: String = "",
    val name: String = "",
    val iconType: String = "TAG",
    val isEnabled: Boolean = true,
    val order: Long = 0L
)
