package com.example.ui.auth

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.example.util.findActivity
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

sealed class GoogleSignInResult {
    data class Success(
        val email: String,
        val displayName: String,
        val idToken: String?,
        val photoUrl: String?
    ) : GoogleSignInResult()

    data class Cancelled(val reason: String = "Google Sign-In was cancelled by user") : GoogleSignInResult()
    data class Error(val message: String) : GoogleSignInResult()
    object NativePickerNeeded : GoogleSignInResult()
}

class GoogleAuthHelper(private val context: Context) {
    private val TAG = "GoogleAuthHelper"
    private val credentialManager = CredentialManager.create(context)

    private fun resolveWebClientId(): String? {
        val defaultRes = context.resources.getIdentifier(
            "default_web_client_id",
            "string",
            context.packageName
        )
        if (defaultRes != 0) {
            val value = context.getString(defaultRes).trim()
            if (value.isNotEmpty()) return value
        }

        val fallbackRes = context.resources.getIdentifier(
            "firebase_web_client_id",
            "string",
            context.packageName
        )
        if (fallbackRes != 0) {
            val value = context.getString(fallbackRes).trim()
            if (value.isNotEmpty()) return value
        }
        return null
    }

    suspend fun signInWithGoogle(): GoogleSignInResult {
        return try {
            val webClientId = resolveWebClientId()
            if (webClientId.isNullOrBlank()) {
                Log.w(
                    TAG,
                    "default_web_client_id not found in google-services.json (oauth_client is empty). Suggesting Guest Mode or Firebase SHA-1 setup."
                )
                return GoogleSignInResult.Error(
                    "Google Sign-In needs SHA-1 & Google provider enabled in Firebase Console (diyan-website). You can tap 'Continue as Guest' below to start right away."
                )
            }

            val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = webClientId).build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(signInOption)
                .build()

            val activityContext = context.findActivity() ?: context
            val response = credentialManager.getCredential(activityContext, request)

            when (val credential = response.credential) {
                is CustomCredential -> {
                    if (credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                        val email = googleIdTokenCredential.id
                        val name = googleIdTokenCredential.displayName
                            ?: email.substringBefore("@").replace(".", " ")
                                .split(" ")
                                .joinToString(" ") { it.replaceFirstChar(Char::uppercaseChar) }
                        GoogleSignInResult.Success(
                            email = email,
                            displayName = name,
                            idToken = googleIdTokenCredential.idToken,
                            photoUrl = googleIdTokenCredential.profilePictureUri?.toString()
                        )
                    } else {
                        GoogleSignInResult.Error("Unexpected credential type received from Google.")
                    }
                }
                else -> {
                    GoogleSignInResult.Error("Unsupported credential response.")
                }
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google Sign-In cancelled by user: ${e.message}", e)
            GoogleSignInResult.Cancelled()
        } catch (e: GetCredentialException) {
            Log.w(TAG, "Credential Manager request failed: ${e.message}", e)
            GoogleSignInResult.Error(
                e.localizedMessage ?: "Google Sign-In unavailable on this build. Tap 'Continue as Guest' below to enter."
            )
        } catch (e: Exception) {
            Log.e(TAG, "Credential Manager exception: ${e.message}", e)
            GoogleSignInResult.Error(
                e.localizedMessage ?: "Google Sign-In error occurred. You can continue as Guest below."
            )
        }
    }
}
