# GemQuest Rewards - Local Test Mode

## Overview
GemQuest Rewards is a native Android application built with **Kotlin** and **Jetpack Compose** following the **MVVM** architecture. It implements a local test rewards platform featuring:
1. **Image Finder Game** (Play rounds to earn Gems, with round deduplication)
2. **Super Offer** (AdMob Rewarded Test Ads, Installation Observation, and 2-Minute Foreground Usage Tracking)
3. **Local Wallet & Ledger** (Coins and Gems tracking with room persistence)
4. **Task History** ("My Super Offers" progress tracker)

---

## Strict Scope & Initial Configuration
- **Initial Mode:** Local Test Mode (no backend or Firebase required)
- **Local Test Configuration:** Defined in `com.example.data.model.TestConfig`:
  - Initial Coins: `0`
  - Initial Gems: `0`
  - Super Offer Required Gems: `2`
  - Super Offer Coin Reward: `10 Coins`
  - Required Target App Usage: `120 seconds` (2 minutes)
  - Game Round Reward: `1 Gem` per completed round (capped at 2 Gems for local test)
  - AdMob Test App ID: `ca-app-pub-3940256099942544~3347511713`
  - AdMob Rewarded Test Ad Unit ID: `ca-app-pub-3940256099942544/5224354917`

---

## 4-Step Super Offer Flow
1. **STEP 1: Watch a video Ad**
   - Loads and displays Google's official Rewarded Test Ad.
   - Reward verified strictly through `onUserEarnedReward`.
2. **STEP 2: Install the app**
   - Takes a launchable package snapshot before installation.
   - User can open Google Play Store to install an app.
   - Rescans visible launcher activities and detects newly observed packages.
   - Displays package name, app label, and marks "Installation Observed".
3. **STEP 3: Use the app for 2 minutes**
   - Prompts for `Settings.ACTION_USAGE_ACCESS_SETTINGS` with clear explanation.
   - Launches selected app via `PackageManager`.
   - Tracks foreground time using `UsageStatsManager` and `UsageEvents`.
   - Displays real-time progress (`X / 120 seconds`) and remaining play time.
4. **STEP 4: Collect Coins**
   - Enabled only when Steps 1, 2, and 3 are successfully completed.
   - Awards 10 Coins to the local wallet once, preventing duplicate claims.

---

## Android Platform Limitations (Documentation)
- **Package Visibility (`<queries>`):** Uses Android's recommended launcher query declaration (`Intent.ACTION_MAIN` + `Intent.CATEGORY_LAUNCHER`) to discover launchable applications without requiring restricted `QUERY_ALL_PACKAGES` permission.
- **Attribution vs. Observation:** A newly observed package proves that an application is installed and launchable, but does not prove advertising attribution from an AdMob test impression.
- **Usage Access:** Requires user consent via system settings (`PACKAGE_USAGE_STATS`). The app tracks foreground event timestamps conservatively.

---

## Running the App & Manual Test Steps
1. Open the project in Android Studio.
2. Build and run on an Android device or emulator (API 26+).
3. **Test 1:** Verify Home screen displays 0 Coins and 0 Gems, Super Offer card (locked), and Image Finder card.
4. **Test 2:** Tap "Gems Collect", play Image Finder rounds, collect 2 Gems.
5. **Test 3:** Return to Home; verify "Unlock Offer" button is enabled.
6. **Test 4:** Tap "Unlock Offer" — 2 Gems are deducted and Super Offer details screen opens.
7. **Test 5:** Watch the test rewarded ad (Step 1 completes upon earned reward).
8. **Test 6:** Install or pick a target app (Step 2 completes).
9. **Test 7:** Grant usage access permission, tap "Play Now", use the app for 120s (Step 3 completes).
10. **Test 8:** Tap "Claim 10 Coins" (Step 4 completes, Wallet updated).
11. **Test 9:** Verify Task History displays the completed offer and duplicate claims are rejected.
