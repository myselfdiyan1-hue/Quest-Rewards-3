package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper

/**
 * Safely extracts an [Activity] from a [Context], unwrapping any [ContextWrapper] layers
 * (such as ContextThemeWrapper or Compose navigation wrappers).
 */
tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
