package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

sealed class GoogleSignInResult {
    data class Success(
        val email: String,
        val displayName: String,
        val idToken: String?,
        val photoUrl: String?
    ) : GoogleSignInResult()

    data class Cancelled(val reason: String = "Google Sign-In was cancelled by user") : GoogleSignInResult()
    data class Error(val message: String) : GoogleSignInResult()
    object NativePickerNeeded : GoogleSignInResult()
}

class GoogleAuthHelper(private val context: Context) {
    private val TAG = "GoogleAuthHelper"
    private val credentialManager = CredentialManager.create(context)

    suspend fun signInWithGoogle(): GoogleSignInResult {
        return try {
            val webClientIdRes = context.resources.getIdentifier(
                "default_web_client_id",
                "string",
                context.packageName
            )
            if (webClientIdRes == 0) {
                Log.e(
                    TAG,
                    "R.string.default_web_client_id not found! Add SHA-1 & enable Google Sign-In in Firebase Console for diyan-website, then re-download google-services.json."
                )
                return GoogleSignInResult.Error(
                    "Google Sign-In configuration missing (default_web_client_id). Please add your SHA-1 fingerprint and enable Google Sign-In in Firebase Console, then update google-services.json."
                )
            }

            val webClientId = context.getString(webClientIdRes)
            if (webClientId.isBlank()) {
                return GoogleSignInResult.Error("default_web_client_id is empty in google-services.json.")
            }

            val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = webClientId).build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(signInOption)
                .build()

            val activityContext = context as? Activity ?: context
            val response = credentialManager.getCredential(activityContext, request)

            when (val credential = response.credential) {
                is CustomCredential -> {
                    if (credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                        val email = googleIdTokenCredential.id
                        val name = googleIdTokenCredential.displayName
                            ?: email.substringBefore("@").replace(".", " ")
                                .split(" ")
                                .joinToString(" ") { it.replaceFirstChar(Char::uppercaseChar) }
                        GoogleSignInResult.Success(
                            email = email,
                            displayName = name,
                            idToken = googleIdTokenCredential.idToken,
                            photoUrl = googleIdTokenCredential.profilePictureUri?.toString()
                        )
                    } else {
                        GoogleSignInResult.Error("Unexpected credential type received from Google.")
                    }
                }
                else -> {
                    GoogleSignInResult.Error("Unsupported credential response.")
                }
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google Sign-In cancelled by user: ${e.message}", e)
            GoogleSignInResult.Cancelled()
        } catch (e: GetCredentialException) {
            Log.w(TAG, "Credential Manager request failed: ${e.message}", e)
            GoogleSignInResult.Error(e.localizedMessage ?: "Google Sign-In failed. Ensure Google Play Services and SHA-1 are configured.")
        } catch (e: Exception) {
            Log.e(TAG, "Credential Manager exception: ${e.message}", e)
            GoogleSignInResult.Error(e.localizedMessage ?: "Google Sign-In error occurred.")
        }
    }
}
