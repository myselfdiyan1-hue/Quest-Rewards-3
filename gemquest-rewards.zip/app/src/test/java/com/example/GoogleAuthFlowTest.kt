package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.firebase.FirebaseManager
import com.example.data.local.AppDatabase
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GoogleAuthFlowTest {

    private lateinit var database: AppDatabase
    private lateinit var rewardRepository: RewardRepository
    private lateinit var firebaseManager: FirebaseManager
    private val testEmail = "testuser.questrewards@gmail.com"
    private val testName = "Test User"

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        firebaseManager = FirebaseManager(context)
        firebaseManager.logout() // start fresh
        rewardRepository = RewardRepository(database.rewardDao(), firebaseManager)
    }

    @After
    fun tearDown() {
        firebaseManager.logout()
        database.close()
    }

    @Test
    fun testFreshInstallHasNoActiveSession() {
        assertFalse(firebaseManager.isLoggedIn.value)
        assertEquals(null, firebaseManager.currentUser.value)
    }

    @Test
    fun testNewGoogleUserGetsWelcomeBonus() = runTest {
        val authResult = firebaseManager.authenticateWithGoogle(
            idToken = null,
            email = testEmail,
            displayName = testName
        )

        assertTrue(authResult.isSuccess)
        val user = authResult.getOrNull()
        assertNotNull(user)
        assertTrue(firebaseManager.isLoggedIn.value)
        assertEquals(testEmail, user?.email)
        assertEquals(50L, user?.coins)
    }

    @Test
    fun testLogoutClearsSessionAndRequiresReAuthentication() = runTest {
        firebaseManager.authenticateWithGoogle(
            idToken = null,
            email = testEmail,
            displayName = testName
        )
        assertTrue(firebaseManager.isLoggedIn.value)

        firebaseManager.logout()

        assertFalse(firebaseManager.isLoggedIn.value)
        assertEquals(null, firebaseManager.currentUser.value)
    }
}
