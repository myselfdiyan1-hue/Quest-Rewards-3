package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = SecondaryBlue,
    onPrimaryContainer = Color.White,
    secondary = PurpleAccent,
    onSecondary = Color.White,
    secondaryContainer = Lavender,
    onSecondaryContainer = PrimaryText,
    tertiary = CoinGold,
    onTertiary = PrimaryText,
    background = MainBackground,
    onBackground = PrimaryText,
    surface = CardWhite,
    onSurface = PrimaryText,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = SecondaryText,
    outline = BorderSubtle
)

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = SecondaryBlue,
    onPrimaryContainer = Color.White,
    secondary = PurpleAccent,
    onSecondary = Color.White,
    tertiary = CoinGold,
    onTertiary = PrimaryText,
    background = Color(0xFF131525),
    onBackground = Color.White,
    surface = Color(0xFF1E2138),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF282C4A),
    onSurfaceVariant = Lavender,
    outline = Color(0xFF33385C)
)

@Composable
fun GemQuestTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Preserve branded light theme as specified in the reference UI
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
