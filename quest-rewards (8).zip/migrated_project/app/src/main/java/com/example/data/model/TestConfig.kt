package com.example.data.model

import com.example.BuildConfig

/**
 * App & AdMob Configuration
 * Automatically uses Google official Test Ad Unit IDs in debug builds
 * and Production Ad Unit IDs in release builds.
 */
object TestConfig {
    val IS_LOCAL_TEST_MODE: Boolean
        get() = BuildConfig.DEBUG

    // Initial Balances (preserved)
    const val INITIAL_COINS = 0
    const val INITIAL_GEMS = 0

    // Super Offer Requirements & Rewards (preserved)
    const val SUPER_OFFER_REQUIRED_GEMS = 2
    const val SUPER_OFFER_COIN_REWARD = 10
    const val REQUIRED_USAGE_SECONDS = 120L // 2 minutes (120 seconds)

    // Image Finder Game Configuration (preserved)
    const val GEM_REWARD_PER_ROUND = 1
    const val MAX_IMAGE_FINDER_GEMS = 999999 // Unlimited gem earning across rounds

    // Official Google AdMob Test Identifiers (Development / Debug Builds)
    const val ADMOB_TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val ADMOB_TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    const val ADMOB_TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
    const val ADMOB_TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"

    // Production AdMob Identifiers (Release Builds)
    const val ADMOB_PROD_APP_ID = "ca-app-pub-8516623795008666~7322569396"
    const val ADMOB_PROD_REWARDED_AD_UNIT_ID = "ca-app-pub-8516623795008666/6563200658"
    const val ADMOB_PROD_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-8516623795008666/3296130216"
    const val ADMOB_PROD_BANNER_AD_UNIT_ID = "ca-app-pub-8516623795008666/8005321012"

    // Active Environment-Aware Ad Unit IDs
    val ADMOB_REWARDED_AD_UNIT_ID: String
        get() = if (BuildConfig.DEBUG) ADMOB_TEST_REWARDED_AD_UNIT_ID else ADMOB_PROD_REWARDED_AD_UNIT_ID

    val ADMOB_INTERSTITIAL_AD_UNIT_ID: String
        get() = if (BuildConfig.DEBUG) ADMOB_TEST_INTERSTITIAL_AD_UNIT_ID else ADMOB_PROD_INTERSTITIAL_AD_UNIT_ID

    val ADMOB_BANNER_AD_UNIT_ID: String
        get() = if (BuildConfig.DEBUG) ADMOB_TEST_BANNER_AD_UNIT_ID else ADMOB_PROD_BANNER_AD_UNIT_ID
}
