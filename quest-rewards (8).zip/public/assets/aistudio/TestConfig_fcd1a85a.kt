package com.example.data.model

/**
 * Local Test Mode Configuration
 * Modifiable without changing UI or business logic code.
 */
object TestConfig {
    const val IS_LOCAL_TEST_MODE = true

    // Initial Balances
    const val INITIAL_COINS = 0
    const val INITIAL_GEMS = 0

    // Super Offer Requirements & Rewards
    const val SUPER_OFFER_REQUIRED_GEMS = 2
    const val SUPER_OFFER_COIN_REWARD = 10
    const val REQUIRED_USAGE_SECONDS = 120L // 2 minutes (120 seconds)

    // Image Finder Game Configuration
    const val GEM_REWARD_PER_ROUND = 1
    const val MAX_IMAGE_FINDER_GEMS = 999999 // Unlimited gem earning across rounds

    // Official Google AdMob Test Identifiers
    const val ADMOB_TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val ADMOB_TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
}
