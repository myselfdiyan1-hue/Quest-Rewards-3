package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StepStatus
import com.example.ui.theme.CoinGold
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.GemCyan
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen

@Composable
fun GemBalanceBadge(
    gems: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFFE0F7FE))
            .border(1.dp, Color(0xFFBCEBFC), RoundedCornerShape(20.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        CyanGemIcon(size = 20.dp)
        Text(
            text = "$gems",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0369A1)
        )
    }
}

@Composable
fun CoinBalanceBadge(
    coins: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFFFEF3C7))
            .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(20.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        GoldCoinIcon(size = 20.dp)
        Text(
            text = "$coins",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF92400E)
        )
    }
}

@Composable
fun StepStatusBadge(
    status: StepStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when (status) {
        StepStatus.NOT_STARTED -> Triple(Color(0xFFF1F5F9), Color(0xFF64748B), "Not Started")
        StepStatus.IN_PROGRESS -> Triple(Color(0xFFEFF6FF), PrimaryBlue, "In Progress")
        StepStatus.PENDING_VERIFICATION -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), "Pending Verification")
        StepStatus.COMPLETED -> Triple(Color(0xFFECFDF5), SuccessGreen, "Completed")
        StepStatus.REJECTED -> Triple(Color(0xFFFEF2F2), ErrorRed, "Rejected")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = textColor
        )
    }
}
