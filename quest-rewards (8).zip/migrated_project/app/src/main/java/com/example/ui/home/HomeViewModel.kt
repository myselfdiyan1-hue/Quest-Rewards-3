package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.OfferSessionEntity
import com.example.data.local.UserBalanceEntity
import com.example.data.model.TestConfig
import com.example.data.repository.RewardRepository
import com.example.tracking.InstallationDetectionRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class HomeUiEvent {
    data class NavigateToSuperOffer(val sessionId: Long) : HomeUiEvent()
    data class ShowMessage(val message: String) : HomeUiEvent()
}

class HomeViewModel(
    private val rewardRepository: RewardRepository,
    private val installationDetectionRepository: InstallationDetectionRepository
) : ViewModel() {

    val balance: StateFlow<UserBalanceEntity> = rewardRepository.balanceFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserBalanceEntity(id = 1, coins = TestConfig.INITIAL_COINS, gems = TestConfig.INITIAL_GEMS)
        )

    val activeOfferSession: StateFlow<OfferSessionEntity?> = rewardRepository.activeOfferSessionFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    private val _eventFlow = MutableSharedFlow<HomeUiEvent>()
    val eventFlow: SharedFlow<HomeUiEvent> = _eventFlow.asSharedFlow()

    val appConfig: StateFlow<com.example.data.firebase.AppConfig> = (rewardRepository.firebaseManager?.appConfig
        ?: MutableStateFlow(com.example.data.firebase.AppConfig()))
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = com.example.data.firebase.AppConfig()
        )

    private val _isUnlocking = MutableStateFlow(false)
    val isUnlocking: StateFlow<Boolean> = _isUnlocking

    init {
        viewModelScope.launch {
            rewardRepository.ensureInitialBalance()
        }
    }

    fun onUnlockOrContinueSuperOffer() {
        viewModelScope.launch {
            val active = activeOfferSession.value
            if (active != null) {
                // Continue existing active offer session without re-deducting gems
                _eventFlow.emit(HomeUiEvent.NavigateToSuperOffer(active.id))
                return@launch
            }

            _isUnlocking.value = true
            try {
                // Take baseline snapshot of visible launchable packages
                val snapshot = installationDetectionRepository.takeLaunchablePackagesSnapshot()
                val result = rewardRepository.unlockSuperOffer(snapshot)
                result.fold(
                    onSuccess = { sessionId ->
                        _eventFlow.emit(HomeUiEvent.NavigateToSuperOffer(sessionId))
                    },
                    onFailure = { error ->
                        _eventFlow.emit(HomeUiEvent.ShowMessage(error.message ?: "Failed to unlock offer"))
                    }
                )
            } finally {
                _isUnlocking.value = false
            }
        }
    }
}

class HomeViewModelFactory(
    private val rewardRepository: RewardRepository,
    private val installationDetectionRepository: InstallationDetectionRepository
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return HomeViewModel(rewardRepository, installationDetectionRepository) as T
    }
}
